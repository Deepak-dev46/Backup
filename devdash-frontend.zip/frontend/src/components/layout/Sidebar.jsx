import React from 'react';
import { NavLink, useLocation } from 'react-router-dom';
import { useAuth } from '../../context/AuthContext';

const devLinks = [
  { to: '/developer', icon: 'bi-speedometer2', label: 'Dashboard', exact: true },
  { to: '/developer/repositories', icon: 'bi-folder2-open', label: 'Repositories' },
  { to: '/developer/metrics', icon: 'bi-graph-up-arrow', label: 'Metrics' },
];

const mgrLinks = [
  { to: '/manager', icon: 'bi-speedometer2', label: 'Dashboard', exact: true },
  { to: '/manager/teams', icon: 'bi-people-fill', label: 'Team Management' },
  { to: '/manager/insights', icon: 'bi-person-lines-fill', label: 'Developer Insights' },
  { to: '/manager/reports', icon: 'bi-file-earmark-bar-graph', label: 'Reports' },
];

export default function Sidebar({ collapsed, mobileOpen, onClose }) {
  const { user } = useAuth();
  const location = useLocation();
  const links = user?.role === 'MANAGER' ? mgrLinks : devLinks;

  return (
    <>
      {mobileOpen && (
        <div
          style={{ position: 'fixed', inset: 0, background: 'rgba(0,0,0,0.5)', zIndex: 999 }}
          onClick={onClose}
        />
      )}
      <div className={`sidebar${collapsed ? ' collapsed' : ''}${mobileOpen ? ' mobile-open' : ''}`}>
        <div className="sidebar-brand">
          <div className="sidebar-brand-icon">
            <i className="bi bi-activity text-white" />
          </div>
          {!collapsed && (
            <div className="sidebar-brand-text">
              DevDash
              <small>Productivity Hub</small>
            </div>
          )}
        </div>

        <nav className="sidebar-nav">
          {!collapsed && (
            <div className="sidebar-section-label">
              {user?.role === 'MANAGER' ? 'Management' : 'Developer'}
            </div>
          )}

          {links.map(link => {
            const isActive = link.exact
              ? location.pathname === link.to
              : location.pathname.startsWith(link.to);
            return (
              <NavLink
                key={link.to}
                to={link.to}
                className={`sidebar-item${isActive ? ' active' : ''}`}
                title={collapsed ? link.label : ''}
                onClick={onClose}
              >
                <i className={`bi ${link.icon} icon`} />
                {!collapsed && <span>{link.label}</span>}
                {!collapsed && link.badge && <span className="badge-dot" />}
              </NavLink>
            );
          })}

          {!collapsed && <div className="sidebar-section-label" style={{ marginTop: 16 }}>System</div>}

          <NavLink to="/login" className="sidebar-item" onClick={() => {
            localStorage.clear();
            window.location.href = '/login';
          }}>
            <i className="bi bi-box-arrow-left icon" />
            {!collapsed && <span>Logout</span>}
          </NavLink>
        </nav>
      </div>
    </>
  );
}
