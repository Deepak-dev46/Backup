import React, { useState } from 'react';
import { useAuth } from '../../context/AuthContext';

const notifications = [
  { id: 1, title: 'Build Failed', msg: 'main branch deployment failed', time: '2m ago', type: 'danger', unread: true },
  { id: 2, title: 'PR Merged', msg: 'feature/auth-fix merged by john', time: '15m ago', type: 'success', unread: true },
  { id: 3, title: 'Low Activity Alert', msg: 'dev@example.com had 0 commits this week', time: '1h ago', type: 'warning', unread: false },
  { id: 4, title: 'New Team Member', msg: 'sarah@dev.io joined Backend Team', time: '3h ago', type: 'info', unread: false },
];

const iconMap = {
  danger: { icon: 'bi-exclamation-triangle-fill', bg: 'rgba(224,25,80,0.1)', color: '#E01950' },
  success: { icon: 'bi-check-circle-fill', bg: 'rgba(34,197,94,0.1)', color: '#16a34a' },
  warning: { icon: 'bi-bell-fill', bg: 'rgba(234,179,8,0.1)', color: '#ca8a04' },
  info: { icon: 'bi-info-circle-fill', bg: 'rgba(39,35,92,0.1)', color: '#27235C' },
};

export default function Navbar({ onToggleSidebar, onMobileMenu }) {
  const { user, darkMode, setDarkMode } = useAuth();
  const [showNotifs, setShowNotifs] = useState(false);
  const [showProfile, setShowProfile] = useState(false);
  const unreadCount = notifications.filter(n => n.unread).length;

  const initials = user?.name?.split(' ').map(w => w[0]).join('').toUpperCase() || 'U';

  return (
    <div className="top-navbar">
      <div className="d-flex align-items-center gap-3">
        <button className="nav-icon-btn d-lg-flex d-none" onClick={onToggleSidebar}>
          <i className="bi bi-layout-sidebar" />
        </button>
        <button className="nav-icon-btn d-lg-none" onClick={onMobileMenu}>
          <i className="bi bi-list" />
        </button>
        <div className="navbar-search">
          <i className="bi bi-search" style={{ color: '#aaa', fontSize: 14 }} />
          <input placeholder="Search repos, commits..." />
        </div>
      </div>

      <div className="navbar-actions">
        {/* Dark Mode Toggle */}
        <button className="nav-icon-btn" onClick={() => setDarkMode(!darkMode)} title="Toggle Dark Mode">
          <i className={`bi ${darkMode ? 'bi-sun-fill' : 'bi-moon-fill'}`} />
        </button>

        {/* Notifications */}
        <div className="position-relative">
          <button className="nav-icon-btn" onClick={() => { setShowNotifs(!showNotifs); setShowProfile(false); }}>
            <i className="bi bi-bell" />
            {unreadCount > 0 && <span className="notif-badge" />}
          </button>

          {showNotifs && (
            <>
              <div style={{ position: 'fixed', inset: 0, zIndex: 100 }} onClick={() => setShowNotifs(false)} />
              <div className="notif-dropdown position-absolute" style={{ right: 0, top: '48px', zIndex: 101 }}>
                <div className="notif-header">
                  <span><i className="bi bi-bell-fill me-2" />Notifications</span>
                  <span className="badge" style={{ background: 'rgba(255,255,255,0.2)' }}>{unreadCount} new</span>
                </div>
                {notifications.map(n => {
                  const { icon, bg, color } = iconMap[n.type];
                  return (
                    <div key={n.id} className={`notif-item${n.unread ? ' unread' : ''}`}>
                      <div style={{ width: 36, height: 36, borderRadius: 10, background: bg, display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0 }}>
                        <i className={`bi ${icon}`} style={{ color, fontSize: 15 }} />
                      </div>
                      <div style={{ flex: 1 }}>
                        <div style={{ fontSize: 13, fontWeight: 600, color: '#222' }}>{n.title}</div>
                        <div style={{ fontSize: 12, color: '#888', marginTop: 2 }}>{n.msg}</div>
                        <div style={{ fontSize: 11, color: '#bbb', marginTop: 4 }}>{n.time}</div>
                      </div>
                      {n.unread && <div className="notif-dot" />}
                    </div>
                  );
                })}
                <div style={{ padding: '12px 20px', textAlign: 'center', fontSize: 13, color: '#97247E', fontWeight: 600, cursor: 'pointer' }}>
                  View all notifications
                </div>
              </div>
            </>
          )}
        </div>

        {/* Profile */}
        <div className="position-relative">
          <div className="avatar" onClick={() => { setShowProfile(!showProfile); setShowNotifs(false); }}>
            {initials}
          </div>

          {showProfile && (
            <>
              <div style={{ position: 'fixed', inset: 0, zIndex: 100 }} onClick={() => setShowProfile(false)} />
              <div className="position-absolute" style={{
                right: 0, top: 44, zIndex: 101,
                background: 'white', borderRadius: 12,
                boxShadow: '0 8px 40px rgba(39,35,92,0.18)',
                border: '1px solid rgba(39,35,92,0.06)',
                minWidth: 220, overflow: 'hidden'
              }}>
                <div style={{ padding: '16px 20px', background: 'linear-gradient(135deg, #27235C, #97247E)', color: 'white' }}>
                  <div style={{ fontWeight: 700, fontSize: 15 }}>{user?.name || 'User'}</div>
                  <div style={{ fontSize: 12, opacity: 0.75, marginTop: 2 }}>{user?.email}</div>
                  <span style={{ background: 'rgba(255,255,255,0.2)', padding: '2px 10px', borderRadius: 20, fontSize: 11, fontWeight: 600, marginTop: 8, display: 'inline-block' }}>
                    {user?.role}
                  </span>
                </div>
                {[
                  { icon: 'bi-person', label: 'Profile Settings' },
                  { icon: 'bi-gear', label: 'Preferences' },
                  { icon: 'bi-shield-check', label: 'Security' },
                ].map(item => (
                  <div key={item.label} style={{ padding: '10px 20px', display: 'flex', alignItems: 'center', gap: 10, cursor: 'pointer', fontSize: 14, color: '#333', transition: 'background 0.2s' }}
                    onMouseEnter={e => e.currentTarget.style.background = '#f8f8f8'}
                    onMouseLeave={e => e.currentTarget.style.background = ''}>
                    <i className={`bi ${item.icon}`} style={{ color: '#97247E' }} />
                    {item.label}
                  </div>
                ))}
                <div style={{ borderTop: '1px solid #f0f0f0' }}>
                  <div style={{ padding: '10px 20px', display: 'flex', alignItems: 'center', gap: 10, cursor: 'pointer', fontSize: 14, color: '#E01950', fontWeight: 600 }}
                    onClick={() => { localStorage.clear(); window.location.href = '/login'; }}>
                    <i className="bi bi-box-arrow-left" />
                    Sign Out
                  </div>
                </div>
              </div>
            </>
          )}
        </div>
      </div>
    </div>
  );
}
