import React from 'react';
import { Line, Bar, Doughnut } from 'react-chartjs-2';
import { Chart as ChartJS, ArcElement, CategoryScale, LinearScale, PointElement, LineElement, BarElement, Title, Tooltip, Legend, Filler } from 'chart.js';

ChartJS.register(ArcElement, CategoryScale, LinearScale, PointElement, LineElement, BarElement, Title, Tooltip, Legend, Filler);

const months = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug'];

const contributionData = {
  labels: months,
  datasets: [
    { label: 'Additions', data: [1200, 1900, 1400, 2200, 1800, 2600, 2100, 2800], fill: true, backgroundColor: 'rgba(39,35,92,0.07)', borderColor: '#27235C', tension: 0.4, borderWidth: 2 },
    { label: 'Deletions', data: [400, 700, 500, 900, 600, 1100, 800, 950], fill: true, backgroundColor: 'rgba(224,25,80,0.06)', borderColor: '#E01950', tension: 0.4, borderWidth: 2 },
  ]
};

const codeDistrib = {
  labels: ['Java', 'TypeScript', 'Python', 'YAML', 'JavaScript'],
  datasets: [{
    data: [35, 28, 20, 10, 7],
    backgroundColor: ['#27235C', '#97247E', '#E01950', '#f59e0b', '#22c55e'],
    borderWidth: 0,
  }]
};

const activityHeatmap = Array.from({ length: 7 }, (_, row) =>
  Array.from({ length: 52 }, (_, col) => Math.floor(Math.random() * 5))
);

const heatColors = ['#f0f0f0', 'rgba(151,36,126,0.2)', 'rgba(151,36,126,0.4)', 'rgba(151,36,126,0.65)', '#97247E'];

const chartOpts = {
  responsive: true, maintainAspectRatio: false,
  plugins: { tooltip: { backgroundColor: '#27235C', padding: 12, cornerRadius: 10 }, legend: { labels: { boxWidth: 10, font: { size: 12 } } } },
  scales: { x: { grid: { display: false }, border: { display: false } }, y: { grid: { color: '#f5f5f5' }, border: { display: false } } }
};

export default function DeveloperMetrics() {
  return (
    <div>
      <div className="page-header">
        <h1 className="page-title">Metrics & Analytics</h1>
        <p className="page-subtitle">Detailed insights into your development contributions</p>
      </div>

      {/* Summary Row */}
      <div className="row g-3 mb-4">
        {[
          { label: 'Lines Added', value: '18,420', delta: '+2,100 this month', up: true, color: '#27235C' },
          { label: 'Lines Deleted', value: '5,830', delta: '-340 this month', up: false, color: '#E01950' },
          { label: 'Net Contribution', value: '+12,590', delta: 'Total net lines', up: true, color: '#97247E' },
          { label: 'Avg Commit Size', value: '53', delta: 'lines per commit', up: true, color: '#22c55e' },
        ].map(s => (
          <div key={s.label} className="col-6 col-lg-3">
            <div className="kpi-card">
              <div className="kpi-value" style={{ color: s.color }}>{s.value}</div>
              <div className="kpi-label">{s.label}</div>
              <div className={`kpi-trend ${s.up ? 'up' : 'down'}`} style={{ marginTop: 8 }}>
                <i className={`bi bi-arrow-${s.up ? 'up' : 'down'}`} />
                {s.delta}
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* Contribution Trend */}
      <div className="row g-3 mb-4">
        <div className="col-lg-8">
          <div className="chart-card">
            <div className="chart-card-header">
              <div>
                <div className="chart-card-title">Code Contribution Trends</div>
                <div className="chart-card-sub">Lines added vs deleted over time</div>
              </div>
              <select className="form-select form-select-sm" style={{ width: 'auto', borderRadius: 8 }}>
                <option>Last 8 Months</option>
                <option>Last Year</option>
              </select>
            </div>
            <div style={{ height: 260 }}>
              <Line data={contributionData} options={chartOpts} />
            </div>
          </div>
        </div>
        <div className="col-lg-4">
          <div className="chart-card">
            <div className="chart-card-header">
              <div>
                <div className="chart-card-title">Language Distribution</div>
                <div className="chart-card-sub">By lines of code</div>
              </div>
            </div>
            <div style={{ height: 200 }}>
              <Doughnut data={codeDistrib} options={{ responsive: true, maintainAspectRatio: false, plugins: { legend: { position: 'bottom', labels: { boxWidth: 10, font: { size: 12 } } } } }} />
            </div>
          </div>
        </div>
      </div>

      {/* Activity Heatmap */}
      <div className="chart-card mb-4">
        <div className="chart-card-header">
          <div>
            <div className="chart-card-title">Contribution Heatmap</div>
            <div className="chart-card-sub">Commit activity over the past year</div>
          </div>
          <div className="d-flex align-items-center gap-2" style={{ fontSize: 12, color: '#aaa' }}>
            Less
            {heatColors.map((c, i) => (
              <div key={i} style={{ width: 12, height: 12, borderRadius: 3, background: c }} />
            ))}
            More
          </div>
        </div>
        <div style={{ overflowX: 'auto' }}>
          <div style={{ display: 'flex', gap: 3, padding: '4px 0' }}>
            {activityHeatmap[0].map((_, col) => (
              <div key={col} style={{ display: 'flex', flexDirection: 'column', gap: 3 }}>
                {activityHeatmap.map((row, rowIdx) => (
                  <div key={rowIdx} title={`${row[col]} commits`} style={{
                    width: 12, height: 12, borderRadius: 3,
                    background: heatColors[row[col]],
                    cursor: 'pointer', transition: 'transform 0.1s'
                  }}
                    onMouseEnter={e => e.target.style.transform = 'scale(1.4)'}
                    onMouseLeave={e => e.target.style.transform = ''}
                  />
                ))}
              </div>
            ))}
          </div>
        </div>
        <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: 11, color: '#ccc', marginTop: 8 }}>
          {['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'].map(m => (
            <span key={m}>{m}</span>
          ))}
        </div>
      </div>

      {/* Monthly Breakdown Table */}
      <div className="data-table">
        <div className="data-table-header">
          <div className="data-table-title">Monthly Breakdown</div>
        </div>
        <div className="table-responsive">
          <table className="table mb-0">
            <thead>
              <tr>
                <th>Month</th>
                <th>Commits</th>
                <th>Lines Added</th>
                <th>Lines Deleted</th>
                <th>PRs Merged</th>
                <th>Issues Closed</th>
                <th>Score</th>
              </tr>
            </thead>
            <tbody>
              {months.map((m, i) => {
                const commits = [32, 48, 41, 55, 47, 63, 58, 72][i];
                const score = [72, 78, 74, 82, 80, 88, 85, 91][i];
                return (
                  <tr key={m}>
                    <td style={{ fontWeight: 600, color: '#27235C' }}>{m} 2024</td>
                    <td>{commits}</td>
                    <td style={{ color: '#27235C' }}>+{(commits * 38).toLocaleString()}</td>
                    <td style={{ color: '#E01950' }}>-{(commits * 12).toLocaleString()}</td>
                    <td>{Math.floor(commits / 4)}</td>
                    <td>{Math.floor(commits / 6)}</td>
                    <td>
                      <div className="d-flex align-items-center gap-2">
                        <div className="progress-custom" style={{ flex: 1, height: 5 }}>
                          <div className="progress-fill" style={{ width: `${score}%` }} />
                        </div>
                        <span style={{ fontSize: 12, fontWeight: 700, color: '#97247E', minWidth: 28 }}>{score}</span>
                      </div>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
