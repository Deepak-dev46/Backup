import React, { useState } from 'react';

const repos = [
  { name: 'devdash-api', lang: 'Java', stars: 142, forks: 38, lastCommit: '2h ago', status: 'active', visibility: 'Private', commits: 347 },
  { name: 'auth-microservice', lang: 'TypeScript', stars: 89, forks: 21, lastCommit: '5h ago', status: 'active', visibility: 'Public', commits: 182 },
  { name: 'react-components-lib', lang: 'JavaScript', stars: 256, forks: 67, lastCommit: '1d ago', status: 'active', visibility: 'Public', commits: 94 },
  { name: 'data-pipeline-utils', lang: 'Python', stars: 34, forks: 9, lastCommit: '3d ago', status: 'warning', visibility: 'Private', commits: 56 },
  { name: 'mobile-client-app', lang: 'Kotlin', stars: 78, forks: 14, lastCommit: '1w ago', status: 'inactive', visibility: 'Private', commits: 23 },
  { name: 'ci-cd-templates', lang: 'YAML', stars: 193, forks: 45, lastCommit: '2h ago', status: 'active', visibility: 'Public', commits: 128 },
  { name: 'ml-inference-engine', lang: 'Python', stars: 312, forks: 89, lastCommit: '6h ago', status: 'active', visibility: 'Public', commits: 201 },
  { name: 'legacy-monolith', lang: 'Java', stars: 12, forks: 3, lastCommit: '2mo ago', status: 'inactive', visibility: 'Private', commits: 8 },
];

const langColors = {
  Java: '#b07219', TypeScript: '#3178c6', JavaScript: '#f1e05a',
  Python: '#3572A5', Kotlin: '#A97BFF', YAML: '#cb171e'
};

export default function DeveloperRepositories() {
  const [search, setSearch] = useState('');
  const [filter, setFilter] = useState('all');

  const filtered = repos.filter(r => {
    const matchSearch = r.name.toLowerCase().includes(search.toLowerCase());
    const matchFilter = filter === 'all' || r.status === filter || r.visibility.toLowerCase() === filter;
    return matchSearch && matchFilter;
  });

  return (
    <div>
      <div className="page-header">
        <div className="d-flex align-items-center justify-content-between flex-wrap gap-3">
          <div>
            <h1 className="page-title">Repositories</h1>
            <p className="page-subtitle">{repos.length} repositories · {repos.filter(r => r.visibility === 'Public').length} public</p>
          </div>
          <button className="btn-gradient">
            <i className="bi bi-plus-lg" />
            New Repository
          </button>
        </div>
      </div>

      {/* Stats Row */}
      <div className="row g-3 mb-4">
        {[
          { label: 'Total Stars', value: repos.reduce((a, r) => a + r.stars, 0), icon: 'bi-star-fill', color: '#f59e0b' },
          { label: 'Total Forks', value: repos.reduce((a, r) => a + r.forks, 0), icon: 'bi-diagram-2-fill', color: '#27235C' },
          { label: 'Active Repos', value: repos.filter(r => r.status === 'active').length, icon: 'bi-lightning-charge-fill', color: '#22c55e' },
          { label: 'Public Repos', value: repos.filter(r => r.visibility === 'Public').length, icon: 'bi-globe', color: '#97247E' },
        ].map(s => (
          <div key={s.label} className="col-6 col-lg-3">
            <div className="kpi-card" style={{ padding: '18px 20px' }}>
              <div className="d-flex align-items-center gap-3">
                <div style={{ width: 44, height: 44, borderRadius: 12, background: `${s.color}18`, display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                  <i className={`bi ${s.icon}`} style={{ color: s.color, fontSize: 20 }} />
                </div>
                <div>
                  <div className="kpi-value" style={{ fontSize: 24 }}>{s.value}</div>
                  <div className="kpi-label">{s.label}</div>
                </div>
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* Filters */}
      <div className="data-table">
        <div className="data-table-header flex-wrap gap-3">
          <div className="data-table-title">All Repositories</div>
          <div className="d-flex gap-2 align-items-center flex-wrap">
            <div style={{ position: 'relative' }}>
              <i className="bi bi-search" style={{ position: 'absolute', left: 12, top: '50%', transform: 'translateY(-50%)', color: '#aaa', fontSize: 14 }} />
              <input
                className="form-control-custom"
                style={{ paddingLeft: 36, width: 220 }}
                placeholder="Search repos..."
                value={search}
                onChange={e => setSearch(e.target.value)}
              />
            </div>
            <select className="form-select form-select-sm" style={{ width: 'auto', borderRadius: 8 }} value={filter} onChange={e => setFilter(e.target.value)}>
              <option value="all">All</option>
              <option value="active">Active</option>
              <option value="inactive">Inactive</option>
              <option value="public">Public</option>
              <option value="private">Private</option>
            </select>
          </div>
        </div>

        <div className="table-responsive">
          <table className="table table-hover mb-0">
            <thead>
              <tr>
                <th>Repository</th>
                <th>Language</th>
                <th><i className="bi bi-star me-1" />Stars</th>
                <th><i className="bi bi-diagram-2 me-1" />Forks</th>
                <th>Commits</th>
                <th>Last Commit</th>
                <th>Visibility</th>
                <th>Status</th>
                <th></th>
              </tr>
            </thead>
            <tbody>
              {filtered.map(repo => (
                <tr key={repo.name}>
                  <td>
                    <div className="d-flex align-items-center gap-2">
                      <div style={{ width: 32, height: 32, borderRadius: 8, background: 'linear-gradient(135deg, #27235C, #97247E)', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                        <i className="bi bi-folder2" style={{ color: 'white', fontSize: 14 }} />
                      </div>
                      <span style={{ fontWeight: 600, color: '#27235C' }}>{repo.name}</span>
                    </div>
                  </td>
                  <td>
                    <div className="d-flex align-items-center gap-2">
                      <div style={{ width: 10, height: 10, borderRadius: '50%', background: langColors[repo.lang] || '#888' }} />
                      <span style={{ fontSize: 13 }}>{repo.lang}</span>
                    </div>
                  </td>
                  <td style={{ fontWeight: 600 }}>⭐ {repo.stars}</td>
                  <td>{repo.forks}</td>
                  <td>
                    <span className="status-badge info">{repo.commits}</span>
                  </td>
                  <td style={{ color: '#888', fontSize: 13 }}>{repo.lastCommit}</td>
                  <td>
                    <span className={`status-badge ${repo.visibility === 'Public' ? 'success' : 'info'}`}>
                      <i className={`bi ${repo.visibility === 'Public' ? 'bi-globe' : 'bi-lock'} me-1`} />
                      {repo.visibility}
                    </span>
                  </td>
                  <td>
                    <span className={`status-badge ${repo.status === 'active' ? 'success' : repo.status === 'warning' ? 'warning' : 'danger'}`}>
                      {repo.status}
                    </span>
                  </td>
                  <td>
                    <div className="d-flex gap-1">
                      <button className="nav-icon-btn" style={{ width: 32, height: 32 }} title="View">
                        <i className="bi bi-eye" style={{ fontSize: 14 }} />
                      </button>
                      <button className="nav-icon-btn" style={{ width: 32, height: 32 }} title="GitHub">
                        <i className="bi bi-github" style={{ fontSize: 14 }} />
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        <div style={{ padding: '16px 24px', borderTop: '1px solid #f0f0f0', display: 'flex', justifyContent: 'between', alignItems: 'center', fontSize: 13, color: '#888' }}>
          Showing {filtered.length} of {repos.length} repositories
        </div>
      </div>
    </div>
  );
}
