import React, { useState, useEffect } from 'react';
import { Line, Bar } from 'react-chartjs-2';
import {
  Chart as ChartJS, CategoryScale, LinearScale, PointElement,
  LineElement, BarElement, Title, Tooltip, Legend, Filler
} from 'chart.js';
import { useAuth } from '../../context/AuthContext';

ChartJS.register(CategoryScale, LinearScale, PointElement, LineElement, BarElement, Title, Tooltip, Legend, Filler);

const mockKPIs = [
  { label: 'Total Commits', value: '347', icon: 'bi-git', color: 'blue', trend: '+12%', up: true, sub: 'This month' },
  { label: 'Pull Requests', value: '28', icon: 'bi-arrow-left-right', color: 'purple', trend: '+5%', up: true, sub: 'Merged this sprint' },
  { label: 'Issues Resolved', value: '64', icon: 'bi-check2-circle', color: 'green', trend: '+18%', up: true, sub: 'This month' },
  { label: 'Productivity Score', value: '87', icon: 'bi-lightning-charge-fill', color: 'red', trend: '+3pts', up: true, sub: 'Out of 100' },
];

const weeklyCommits = {
  labels: ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'],
  datasets: [{
    label: 'Commits',
    data: [12, 19, 8, 24, 17, 6, 4],
    fill: true,
    backgroundColor: 'rgba(151, 36, 126, 0.08)',
    borderColor: '#97247E',
    borderWidth: 2.5,
    pointBackgroundColor: '#97247E',
    pointRadius: 4,
    tension: 0.4,
  }]
};

const prData = {
  labels: ['Week 1', 'Week 2', 'Week 3', 'Week 4'],
  datasets: [
    {
      label: 'Merged',
      data: [8, 12, 6, 10],
      backgroundColor: '#27235C',
      borderRadius: 8,
    },
    {
      label: 'Open',
      data: [3, 5, 4, 2],
      backgroundColor: '#97247E',
      borderRadius: 8,
    },
    {
      label: 'Closed',
      data: [2, 1, 3, 1],
      backgroundColor: '#E01950',
      borderRadius: 8,
    }
  ]
};

const timeline = [
  { icon: 'bi-git', bg: 'rgba(39,35,92,0.1)', color: '#27235C', text: 'Pushed 3 commits to feature/auth-module', time: '2 hours ago' },
  { icon: 'bi-arrow-left-right', bg: 'rgba(151,36,126,0.1)', color: '#97247E', text: 'PR #47 merged: Fix user session handling', time: '5 hours ago' },
  { icon: 'bi-check2-circle', bg: 'rgba(34,197,94,0.1)', color: '#22c55e', text: 'Closed issue #103: Login redirect bug', time: 'Yesterday' },
  { icon: 'bi-lightning-charge', bg: 'rgba(224,25,80,0.1)', color: '#E01950', text: 'GitHub Actions: Build passed on main', time: 'Yesterday' },
  { icon: 'bi-star', bg: 'rgba(234,179,8,0.1)', color: '#ca8a04', text: 'Repository devdash-api starred by 5 users', time: '2 days ago' },
];

const chartOpts = {
  responsive: true,
  maintainAspectRatio: false,
  plugins: { legend: { display: false }, tooltip: { backgroundColor: '#27235C', padding: 12, cornerRadius: 10 } },
  scales: { x: { grid: { display: false }, border: { display: false } }, y: { grid: { color: '#f5f5f5' }, border: { display: false } } }
};

export default function DeveloperDashboard() {
  const { user } = useAuth();
  const [animateKpi, setAnimateKpi] = useState(false);

  useEffect(() => {
    const t = setTimeout(() => setAnimateKpi(true), 100);
    return () => clearTimeout(t);
  }, []);

  return (
    <div>
      <div className="page-header">
        <div className="d-flex align-items-center justify-content-between flex-wrap gap-3">
          <div>
            <h1 className="page-title">
              Good morning, {user?.name?.split(' ')[0] || 'Developer'} 👋
            </h1>
            <p className="page-subtitle">Here's what's happening with your code today.</p>
          </div>
          <div className="d-flex gap-2">
            <button className="btn-gradient">
              <i className="bi bi-arrow-clockwise" />
              Sync GitHub
            </button>
          </div>
        </div>
      </div>

      {/* KPI Cards */}
      <div className="row g-3 mb-4">
        {mockKPIs.map((kpi, i) => (
          <div key={kpi.label} className="col-lg-3 col-sm-6">
            <div className="kpi-card" style={{ opacity: animateKpi ? 1 : 0, transform: animateKpi ? 'none' : 'translateY(20px)', transition: `all 0.5s ${i * 0.1}s` }}>
              <div className={`kpi-icon ${kpi.color}`}>
                <i className={`bi ${kpi.icon}`} />
              </div>
              <div className="kpi-value">{kpi.value}</div>
              <div className="kpi-label">{kpi.label}</div>
              <div className="d-flex align-items-center justify-content-between mt-2">
                <span className="kpi-trend up">
                  <i className="bi bi-arrow-up" />{kpi.trend}
                </span>
                <span style={{ fontSize: 11, color: '#bbb' }}>{kpi.sub}</span>
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* Charts Row */}
      <div className="row g-3 mb-4">
        <div className="col-lg-8">
          <div className="chart-card">
            <div className="chart-card-header">
              <div>
                <div className="chart-card-title">Weekly Commit Activity</div>
                <div className="chart-card-sub">Last 7 days across all repositories</div>
              </div>
              <select className="form-select form-select-sm" style={{ width: 'auto', borderRadius: 8, fontSize: 13 }}>
                <option>This Week</option>
                <option>Last Week</option>
                <option>Last Month</option>
              </select>
            </div>
            <div style={{ height: 240 }}>
              <Line data={weeklyCommits} options={chartOpts} />
            </div>
          </div>
        </div>
        <div className="col-lg-4">
          <div className="chart-card">
            <div className="chart-card-header">
              <div>
                <div className="chart-card-title">PR Status</div>
                <div className="chart-card-sub">Monthly breakdown</div>
              </div>
            </div>
            <div style={{ height: 240 }}>
              <Bar data={prData} options={{ ...chartOpts, plugins: { ...chartOpts.plugins, legend: { display: true, position: 'bottom', labels: { boxWidth: 10, font: { size: 11 } } } } }} />
            </div>
          </div>
        </div>
      </div>

      {/* Activity & Score */}
      <div className="row g-3">
        <div className="col-lg-7">
          <div className="chart-card">
            <div className="chart-card-header">
              <div className="chart-card-title">Recent Activity</div>
              <span className="status-badge info">Live</span>
            </div>
            <div className="timeline">
              {timeline.map((item, i) => (
                <div key={i} className="timeline-item">
                  <div className="timeline-icon" style={{ background: item.bg }}>
                    <i className={`bi ${item.icon}`} style={{ color: item.color, fontSize: 15 }} />
                  </div>
                  <div className="timeline-content">
                    <div className="timeline-text">{item.text}</div>
                    <div className="timeline-time">{item.time}</div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
        <div className="col-lg-5">
          <div className="chart-card">
            <div className="chart-card-title mb-4">Productivity Breakdown</div>
            {[
              { label: 'Code Quality', value: 92, color: '#27235C' },
              { label: 'Commit Frequency', value: 78, color: '#97247E' },
              { label: 'PR Review Speed', value: 85, color: '#E01950' },
              { label: 'Issue Resolution', value: 70, color: '#22c55e' },
              { label: 'Documentation', value: 60, color: '#f59e0b' },
            ].map(item => (
              <div key={item.label} className="mb-3">
                <div className="d-flex justify-content-between mb-1">
                  <span style={{ fontSize: 13, color: '#555' }}>{item.label}</span>
                  <span style={{ fontSize: 13, fontWeight: 700, color: item.color }}>{item.value}%</span>
                </div>
                <div className="progress-custom">
                  <div className="progress-fill" style={{ width: `${item.value}%`, background: `linear-gradient(90deg, ${item.color}88, ${item.color})` }} />
                </div>
              </div>
            ))}

            <div style={{ marginTop: 20, padding: '16px', background: 'linear-gradient(135deg, rgba(39,35,92,0.05), rgba(151,36,126,0.05))', borderRadius: 12 }}>
              <div style={{ fontSize: 13, color: '#888', marginBottom: 4 }}>Overall Score</div>
              <div style={{ fontSize: 40, fontWeight: 900, background: 'linear-gradient(135deg, #27235C, #97247E)', WebkitBackgroundClip: 'text', WebkitTextFillColor: 'transparent' }}>87</div>
              <div style={{ fontSize: 12, color: '#aaa' }}>Top 15% of all developers</div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
