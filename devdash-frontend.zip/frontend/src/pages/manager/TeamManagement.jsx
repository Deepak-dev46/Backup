import React, { useState } from 'react';

const initialTeams = [
  { id: 1, name: 'Frontend Team', members: ['Alex Chen', 'Tom Brown'], lead: 'Alex Chen', repos: 5, status: 'active' },
  { id: 2, name: 'Backend Team', members: ['Maria Garcia', 'Lisa Kim'], lead: 'Maria Garcia', repos: 8, status: 'active' },
  { id: 3, name: 'DevOps Team', members: ['James Wilson'], lead: 'James Wilson', repos: 3, status: 'active' },
  { id: 4, name: 'Full Stack Team', members: ['Priya Patel'], lead: 'Priya Patel', repos: 6, status: 'active' },
];

const allDevs = ['Alex Chen', 'Maria Garcia', 'James Wilson', 'Priya Patel', 'Tom Brown', 'Lisa Kim', 'Sam Lee', 'Nina Ross'];

const avatarColors = ['#27235C', '#97247E', '#E01950', '#f59e0b', '#22c55e', '#3b82f6'];

export default function TeamManagement() {
  const [teams, setTeams] = useState(initialTeams);
  const [showModal, setShowModal] = useState(false);
  const [showAddMember, setShowAddMember] = useState(null);
  const [newTeam, setNewTeam] = useState({ name: '', lead: '', members: [] });

  const handleCreate = () => {
    if (!newTeam.name) return;
    setTeams([...teams, { id: teams.length + 1, ...newTeam, repos: 0, status: 'active' }]);
    setShowModal(false);
    setNewTeam({ name: '', lead: '', members: [] });
  };

  const handleRemoveMember = (teamId, member) => {
    setTeams(teams.map(t => t.id === teamId ? { ...t, members: t.members.filter(m => m !== member) } : t));
  };

  const handleAddMember = (teamId, member) => {
    if (!member) return;
    setTeams(teams.map(t => t.id === teamId && !t.members.includes(member) ? { ...t, members: [...t.members, member] } : t));
    setShowAddMember(null);
  };

  return (
    <div>
      <div className="page-header">
        <div className="d-flex justify-content-between align-items-center flex-wrap gap-3">
          <div>
            <h1 className="page-title">Team Management</h1>
            <p className="page-subtitle">{teams.length} teams · {teams.reduce((a,t) => a+t.members.length, 0)} developers</p>
          </div>
          <button className="btn-gradient" onClick={() => setShowModal(true)}>
            <i className="bi bi-plus-lg" />
            Create Team
          </button>
        </div>
      </div>

      <div className="row g-3">
        {teams.map((team, ti) => (
          <div key={team.id} className="col-lg-6">
            <div className="chart-card h-100">
              <div className="d-flex align-items-start justify-content-between mb-4">
                <div className="d-flex align-items-center gap-3">
                  <div style={{ width: 48, height: 48, borderRadius: 14, background: 'linear-gradient(135deg, #27235C, #97247E)', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                    <i className="bi bi-people-fill" style={{ color: 'white', fontSize: 20 }} />
                  </div>
                  <div>
                    <div style={{ fontWeight: 700, fontSize: 16, color: '#27235C' }}>{team.name}</div>
                    <div style={{ fontSize: 12, color: '#aaa' }}>Lead: {team.lead}</div>
                  </div>
                </div>
                <div className="d-flex gap-2">
                  <span className="status-badge success">{team.repos} repos</span>
                  <button className="nav-icon-btn" style={{ width: 32, height: 32 }}>
                    <i className="bi bi-pencil" style={{ fontSize: 13 }} />
                  </button>
                </div>
              </div>

              <div style={{ marginBottom: 16 }}>
                <div style={{ fontSize: 12, fontWeight: 600, color: '#888', marginBottom: 10, textTransform: 'uppercase', letterSpacing: '0.8px' }}>
                  Members ({team.members.length})
                </div>
                <div className="d-flex flex-column gap-2">
                  {team.members.map((member, mi) => (
                    <div key={member} className="d-flex align-items-center justify-content-between" style={{ padding: '8px 12px', background: '#f8f9ff', borderRadius: 10 }}>
                      <div className="d-flex align-items-center gap-3">
                        <div style={{ width: 30, height: 30, borderRadius: 8, background: avatarColors[mi % avatarColors.length], display: 'flex', alignItems: 'center', justifyContent: 'center', color: 'white', fontWeight: 700, fontSize: 12 }}>
                          {member.split(' ').map(w => w[0]).join('')}
                        </div>
                        <span style={{ fontSize: 14, fontWeight: 500 }}>{member}</span>
                      </div>
                      <button onClick={() => handleRemoveMember(team.id, member)} style={{ border: 'none', background: 'none', color: '#E01950', cursor: 'pointer', padding: '2px 6px', borderRadius: 6, fontSize: 13 }}>
                        <i className="bi bi-x-circle" />
                      </button>
                    </div>
                  ))}
                </div>
              </div>

              {showAddMember === team.id ? (
                <div className="d-flex gap-2">
                  <select className="form-select form-select-sm" id={`add-${team.id}`} style={{ borderRadius: 8 }}>
                    <option value="">Select developer...</option>
                    {allDevs.filter(d => !team.members.includes(d)).map(d => (
                      <option key={d} value={d}>{d}</option>
                    ))}
                  </select>
                  <button className="btn-gradient" style={{ padding: '6px 14px', fontSize: 13 }}
                    onClick={() => handleAddMember(team.id, document.getElementById(`add-${team.id}`).value)}>
                    Add
                  </button>
                  <button onClick={() => setShowAddMember(null)} style={{ border: 'none', background: '#f0f0f0', borderRadius: 8, padding: '6px 12px', cursor: 'pointer' }}>Cancel</button>
                </div>
              ) : (
                <button
                  onClick={() => setShowAddMember(team.id)}
                  style={{ width: '100%', padding: '9px', border: '2px dashed #e0e0e0', borderRadius: 10, background: 'none', color: '#97247E', fontWeight: 600, fontSize: 13, cursor: 'pointer', transition: 'all 0.2s' }}
                  onMouseEnter={e => e.target.style.borderColor = '#97247E'}
                  onMouseLeave={e => e.target.style.borderColor = '#e0e0e0'}
                >
                  <i className="bi bi-person-plus me-2" />Add Developer
                </button>
              )}
            </div>
          </div>
        ))}
      </div>

      {/* Create Team Modal */}
      {showModal && (
        <div className="modal d-block" style={{ background: 'rgba(0,0,0,0.5)' }}>
          <div className="modal-dialog modal-dialog-centered">
            <div className="modal-content">
              <div className="modal-header-custom">
                <div className="d-flex align-items-center justify-content-between">
                  <div>
                    <h5 style={{ margin: 0, fontWeight: 700 }}>Create New Team</h5>
                    <p style={{ margin: 0, fontSize: 12, opacity: 0.7 }}>Set up a new development team</p>
                  </div>
                  <button onClick={() => setShowModal(false)} style={{ border: 'none', background: 'rgba(255,255,255,0.15)', color: 'white', width: 32, height: 32, borderRadius: 8, cursor: 'pointer', fontSize: 18 }}>×</button>
                </div>
              </div>
              <div className="modal-body p-4">
                <div className="mb-3">
                  <label style={{ fontSize: 13, fontWeight: 600, color: '#555', marginBottom: 6, display: 'block' }}>Team Name *</label>
                  <input className="form-control-custom" placeholder="e.g. Mobile Team" value={newTeam.name} onChange={e => setNewTeam({ ...newTeam, name: e.target.value })} />
                </div>
                <div className="mb-3">
                  <label style={{ fontSize: 13, fontWeight: 600, color: '#555', marginBottom: 6, display: 'block' }}>Team Lead</label>
                  <select className="form-control-custom" value={newTeam.lead} onChange={e => setNewTeam({ ...newTeam, lead: e.target.value })}>
                    <option value="">Select lead...</option>
                    {allDevs.map(d => <option key={d} value={d}>{d}</option>)}
                  </select>
                </div>
                <div className="mb-3">
                  <label style={{ fontSize: 13, fontWeight: 600, color: '#555', marginBottom: 6, display: 'block' }}>Initial Members</label>
                  <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 8 }}>
                    {allDevs.map(d => (
                      <label key={d} style={{ display: 'flex', alignItems: 'center', gap: 8, padding: '8px 12px', background: newTeam.members.includes(d) ? 'rgba(151,36,126,0.08)' : '#f8f8f8', borderRadius: 8, cursor: 'pointer', fontSize: 13 }}>
                        <input type="checkbox" checked={newTeam.members.includes(d)} onChange={e => {
                          setNewTeam({ ...newTeam, members: e.target.checked ? [...newTeam.members, d] : newTeam.members.filter(m => m !== d) });
                        }} />
                        {d}
                      </label>
                    ))}
                  </div>
                </div>
              </div>
              <div className="modal-footer border-0 px-4 pb-4">
                <button onClick={() => setShowModal(false)} className="btn-outline-primary-custom me-2">Cancel</button>
                <button onClick={handleCreate} className="btn-gradient">
                  <i className="bi bi-check2 me-1" />Create Team
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
