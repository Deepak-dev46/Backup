import React, { useState } from 'react';

const developers = [
  { rank: 1, name: 'Alex Chen', email: 'alex@dev.io', team: 'Frontend', commits: 89, prs: 12, issues: 28, score: 91, trend: 'up' },
  { rank: 2, name: 'Maria Garcia', email: 'maria@dev.io', team: 'Backend', commits: 74, prs: 9, issues: 21, score: 85, trend: 'up' },
  { rank: 3, name: 'James Wilson', email: 'james@dev.io', team: 'DevOps', commits: 62, prs: 7, issues: 15, score: 78, trend: 'stable' },
  { rank: 4, name: 'Priya Patel', email: 'priya@dev.io', team: 'Full Stack', commits: 56, prs: 8, issues: 19, score: 74, trend: 'up' },
  { rank: 5, name: 'Tom Brown', email: 'tom@dev.io', team: 'Frontend', commits: 18, prs: 2, issues: 4, score: 34, trend: 'down' },
  { rank: 6, name: 'Lisa Kim', email: 'lisa@dev.io', team: 'Backend', commits: 12, prs: 1, issues: 2, score: 28, trend: 'down' },
];

const rankColors = { 1: '#f59e0b', 2: '#94a3b8', 3: '#cd7c3a' };

export default function DeveloperInsights() {
  const [sort, setSort] = useState('score');
  const [filter, setFilter] = useState('all');

  const sorted = [...developers]
    .filter(d => filter === 'all' || (filter === 'risk' && d.score < 50) || (filter === 'top' && d.score >= 80))
    .sort((a, b) => b[sort] - a[sort]);

  return (
    <div>
      <div className="page-header">
        <div className="d-flex justify-content-between align-items-center flex-wrap gap-3">
          <div>
            <h1 className="page-title">Developer Insights</h1>
            <p className="page-subtitle">Leaderboard and individual performance metrics</p>
          </div>
          <div className="d-flex gap-2">
            <select className="form-select form-select-sm" style={{ width: 'auto', borderRadius: 8 }} value={filter} onChange={e => setFilter(e.target.value)}>
              <option value="all">All Developers</option>
              <option value="top">Top Performers</option>
              <option value="risk">At Risk</option>
            </select>
            <select className="form-select form-select-sm" style={{ width: 'auto', borderRadius: 8 }} value={sort} onChange={e => setSort(e.target.value)}>
              <option value="score">By Score</option>
              <option value="commits">By Commits</option>
              <option value="prs">By PRs</option>
            </select>
          </div>
        </div>
      </div>

      {/* Top 3 Podium */}
      <div className="row g-3 mb-4">
        {developers.slice(0, 3).map((dev, i) => (
          <div key={dev.name} className="col-lg-4">
            <div className="kpi-card" style={{ textAlign: 'center', position: 'relative' }}>
              {i === 0 && (
                <div style={{ position: 'absolute', top: 12, right: 12, fontSize: 20 }}>👑</div>
              )}
              <div style={{
                width: 64, height: 64, borderRadius: 18,
                background: i === 0 ? 'linear-gradient(135deg, #f59e0b, #fbbf24)' : i === 1 ? 'linear-gradient(135deg, #94a3b8, #cbd5e1)' : 'linear-gradient(135deg, #cd7c3a, #e09150)',
                display: 'flex', alignItems: 'center', justifyContent: 'center',
                margin: '0 auto 12px', color: 'white', fontWeight: 800, fontSize: 22
              }}>
                {dev.name.split(' ').map(w => w[0]).join('')}
              </div>
              <div style={{ fontWeight: 700, fontSize: 15, color: '#27235C' }}>{dev.name}</div>
              <div style={{ fontSize: 12, color: '#aaa', marginBottom: 12 }}>{dev.team}</div>
              <div style={{ fontSize: 36, fontWeight: 900, background: 'linear-gradient(135deg, #27235C, #97247E)', WebkitBackgroundClip: 'text', WebkitTextFillColor: 'transparent' }}>
                {dev.score}
              </div>
              <div style={{ fontSize: 12, color: '#aaa', marginBottom: 12 }}>Productivity Score</div>
              <div className="d-flex justify-content-center gap-3" style={{ fontSize: 13 }}>
                <div><span style={{ fontWeight: 700 }}>{dev.commits}</span> <span style={{ color: '#aaa' }}>commits</span></div>
                <div><span style={{ fontWeight: 700 }}>{dev.prs}</span> <span style={{ color: '#aaa' }}>PRs</span></div>
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* Full Leaderboard Table */}
      <div className="data-table">
        <div className="data-table-header">
          <div className="data-table-title">Full Leaderboard</div>
          <span style={{ fontSize: 13, color: '#aaa' }}>Updated just now</span>
        </div>
        <div className="table-responsive">
          <table className="table mb-0">
            <thead>
              <tr>
                <th>Rank</th>
                <th>Developer</th>
                <th>Team</th>
                <th>Commits</th>
                <th>PRs Merged</th>
                <th>Issues</th>
                <th>Score</th>
                <th>Trend</th>
                <th>Actions</th>
              </tr>
            </thead>
            <tbody>
              {sorted.map((dev) => {
                const isRisk = dev.score < 50;
                return (
                  <tr key={dev.name} style={isRisk ? { background: 'rgba(224,25,80,0.025)' } : {}}>
                    <td>
                      <div className={`rank-badge ${dev.rank <= 3 ? `rank-${dev.rank}` : 'rank-other'}`}>
                        {dev.rank}
                      </div>
                    </td>
                    <td>
                      <div className="d-flex align-items-center gap-3">
                        <div style={{
                          width: 36, height: 36, borderRadius: 10, fontWeight: 700, fontSize: 13,
                          background: isRisk ? 'linear-gradient(135deg, #E01950, #c01440)' : `linear-gradient(135deg, ${['#27235C','#97247E','#f59e0b','#3b82f6','#22c55e'][dev.rank % 5]}, ${['#97247E','#E01950','#f97316','#8b5cf6','#14b8a6'][dev.rank % 5]})`,
                          display: 'flex', alignItems: 'center', justifyContent: 'center', color: 'white'
                        }}>
                          {dev.name.split(' ').map(w => w[0]).join('')}
                        </div>
                        <div>
                          <div style={{ fontWeight: 600, fontSize: 14 }}>{dev.name}</div>
                          <div style={{ fontSize: 11, color: '#bbb' }}>{dev.email}</div>
                        </div>
                      </div>
                    </td>
                    <td><span className="status-badge info">{dev.team}</span></td>
                    <td style={{ fontWeight: 600 }}>{dev.commits}</td>
                    <td>{dev.prs}</td>
                    <td>{dev.issues}</td>
                    <td>
                      <div className="d-flex align-items-center gap-2">
                        <div style={{ position: 'relative', width: 44, height: 44 }}>
                          <svg width="44" height="44" viewBox="0 0 44 44">
                            <circle cx="22" cy="22" r="18" fill="none" stroke="#f0f0f0" strokeWidth="4" />
                            <circle cx="22" cy="22" r="18" fill="none"
                              stroke={isRisk ? '#E01950' : dev.score >= 80 ? '#27235C' : '#f59e0b'}
                              strokeWidth="4"
                              strokeDasharray={`${(dev.score / 100) * 113} 113`}
                              strokeLinecap="round"
                              transform="rotate(-90 22 22)"
                            />
                            <text x="22" y="27" textAnchor="middle" fontSize="11" fontWeight="700" fill={isRisk ? '#E01950' : '#27235C'}>{dev.score}</text>
                          </svg>
                        </div>
                      </div>
                    </td>
                    <td>
                      <span className={`kpi-trend ${dev.trend === 'up' ? 'up' : dev.trend === 'down' ? 'down' : ''}`} style={{ background: dev.trend === 'stable' ? '#f0f0f0' : undefined, color: dev.trend === 'stable' ? '#888' : undefined }}>
                        <i className={`bi bi-arrow-${dev.trend === 'up' ? 'up' : dev.trend === 'down' ? 'down' : 'right'}`} />
                        {dev.trend}
                      </span>
                    </td>
                    <td>
                      <div className="d-flex gap-1">
                        <button className="btn-gradient" style={{ padding: '5px 12px', fontSize: 12 }}>Profile</button>
                        {isRisk && (
                          <button className="btn-danger-custom" style={{ padding: '5px 12px', fontSize: 12 }}>Alert</button>
                        )}
                      </div>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
