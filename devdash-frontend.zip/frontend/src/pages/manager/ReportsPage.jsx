import React, { useState } from 'react';
import { Bar, Line } from 'react-chartjs-2';
import { Chart as ChartJS, CategoryScale, LinearScale, BarElement, LineElement, PointElement, Title, Tooltip, Legend, Filler } from 'chart.js';

ChartJS.register(CategoryScale, LinearScale, BarElement, LineElement, PointElement, Title, Tooltip, Legend, Filler);

const months = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug'];

const monthlyCommits = {
  labels: months,
  datasets: [
    { label: 'Alex C.', data: [72, 85, 78, 91, 83, 96, 89, 94], backgroundColor: '#27235C', borderRadius: 6 },
    { label: 'Maria G.', data: [58, 67, 72, 74, 68, 79, 74, 80], backgroundColor: '#97247E', borderRadius: 6 },
    { label: 'James W.', data: [44, 52, 49, 58, 55, 63, 62, 68], backgroundColor: '#E01950', borderRadius: 6 },
  ]
};

const velocityTrend = {
  labels: ['Sprint 1', 'Sprint 2', 'Sprint 3', 'Sprint 4', 'Sprint 5', 'Sprint 6', 'Sprint 7', 'Sprint 8'],
  datasets: [{
    label: 'Team Velocity',
    data: [38, 45, 42, 55, 58, 63, 68, 72],
    fill: true,
    backgroundColor: 'rgba(39,35,92,0.07)',
    borderColor: '#27235C',
    tension: 0.4,
    borderWidth: 2.5,
    pointBackgroundColor: '#97247E',
    pointRadius: 5,
  }]
};

const chartOpts = {
  responsive: true, maintainAspectRatio: false,
  plugins: { legend: { labels: { boxWidth: 10, font: { size: 12 } } }, tooltip: { backgroundColor: '#27235C', padding: 12, cornerRadius: 10 } },
  scales: { x: { grid: { display: false }, border: { display: false } }, y: { grid: { color: '#f5f5f5' }, border: { display: false } } }
};

const reportTypes = [
  { id: 'sprint', label: 'Sprint Report', desc: 'Velocity, stories, blockers', icon: 'bi-lightning-charge' },
  { id: 'monthly', label: 'Monthly Summary', desc: 'Commits, PRs, issues by dev', icon: 'bi-calendar-month' },
  { id: 'performance', label: 'Performance Review', desc: 'Individual scores & trends', icon: 'bi-person-check' },
  { id: 'cicd', label: 'CI/CD Report', desc: 'Build success rates & times', icon: 'bi-gear' },
];

export default function ReportsPage() {
  const [generating, setGenerating] = useState(null);

  const handleExport = (type, format) => {
    setGenerating(`${type}-${format}`);
    setTimeout(() => setGenerating(null), 1800);
  };

  return (
    <div>
      <div className="page-header">
        <div className="d-flex justify-content-between align-items-center flex-wrap gap-3">
          <div>
            <h1 className="page-title">Reports & Analytics</h1>
            <p className="page-subtitle">Generate, export and share team performance reports</p>
          </div>
          <div className="d-flex align-items-center gap-2">
            <select className="form-select form-select-sm" style={{ width: 'auto', borderRadius: 8 }}>
              <option>April 2024</option>
              <option>March 2024</option>
              <option>Q1 2024</option>
            </select>
          </div>
        </div>
      </div>

      {/* Report Cards */}
      <div className="row g-3 mb-4">
        {reportTypes.map(r => (
          <div key={r.id} className="col-lg-3 col-sm-6">
            <div className="kpi-card" style={{ padding: '20px' }}>
              <div style={{ width: 44, height: 44, borderRadius: 12, background: 'linear-gradient(135deg, rgba(39,35,92,0.1), rgba(151,36,126,0.1))', display: 'flex', alignItems: 'center', justifyContent: 'center', marginBottom: 12 }}>
                <i className={`bi ${r.icon}`} style={{ fontSize: 20, color: '#97247E' }} />
              </div>
              <div style={{ fontWeight: 700, fontSize: 14, color: '#27235C', marginBottom: 4 }}>{r.label}</div>
              <div style={{ fontSize: 12, color: '#aaa', marginBottom: 16 }}>{r.desc}</div>
              <div className="d-flex gap-2">
                <button
                  className="btn-gradient"
                  style={{ padding: '6px 12px', fontSize: 12, flex: 1, justifyContent: 'center' }}
                  onClick={() => handleExport(r.id, 'pdf')}
                  disabled={!!generating}
                >
                  {generating === `${r.id}-pdf` ? (
                    <span className="spinner-border spinner-border-sm" />
                  ) : (
                    <><i className="bi bi-file-pdf me-1" />PDF</>
                  )}
                </button>
                <button
                  className="btn-outline-primary-custom"
                  style={{ padding: '6px 12px', fontSize: 12, flex: 1 }}
                  onClick={() => handleExport(r.id, 'csv')}
                  disabled={!!generating}
                >
                  {generating === `${r.id}-csv` ? (
                    <span className="spinner-border spinner-border-sm" />
                  ) : (
                    <><i className="bi bi-filetype-csv me-1" />CSV</>
                  )}
                </button>
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* Charts */}
      <div className="row g-3 mb-4">
        <div className="col-lg-7">
          <div className="chart-card">
            <div className="chart-card-header">
              <div>
                <div className="chart-card-title">Monthly Commits by Developer</div>
                <div className="chart-card-sub">Comparison across top 3 developers</div>
              </div>
              <button className="btn-gradient" style={{ padding: '6px 14px', fontSize: 12 }} onClick={() => handleExport('monthly', 'pdf')}>
                {generating === 'monthly-pdf' ? <span className="spinner-border spinner-border-sm" /> : <><i className="bi bi-download me-1" />Export</>}
              </button>
            </div>
            <div style={{ height: 260 }}>
              <Bar data={monthlyCommits} options={chartOpts} />
            </div>
          </div>
        </div>
        <div className="col-lg-5">
          <div className="chart-card">
            <div className="chart-card-header">
              <div>
                <div className="chart-card-title">Sprint Velocity Trend</div>
                <div className="chart-card-sub">Team velocity over 8 sprints</div>
              </div>
            </div>
            <div style={{ height: 260 }}>
              <Line data={velocityTrend} options={{ ...chartOpts, plugins: { ...chartOpts.plugins, legend: { display: false } } }} />
            </div>
          </div>
        </div>
      </div>

      {/* Detailed Stats Table */}
      <div className="data-table">
        <div className="data-table-header">
          <div className="data-table-title">Monthly Analytics — April 2024</div>
          <div className="d-flex gap-2">
            <button className="btn-danger-custom" style={{ padding: '7px 16px', fontSize: 13 }} onClick={() => handleExport('all', 'pdf')}>
              <i className="bi bi-file-pdf me-2" />Full PDF
            </button>
            <button className="btn-gradient" style={{ padding: '7px 16px', fontSize: 13 }} onClick={() => handleExport('all', 'csv')}>
              <i className="bi bi-download me-2" />Export CSV
            </button>
          </div>
        </div>
        <div className="table-responsive">
          <table className="table mb-0">
            <thead>
              <tr>
                <th>Developer</th>
                <th>Commits</th>
                <th>Lines Added</th>
                <th>PRs Merged</th>
                <th>Issues Closed</th>
                <th>Build Success</th>
                <th>Score</th>
              </tr>
            </thead>
            <tbody>
              {[
                { name: 'Alex Chen', commits: 89, lines: 4200, prs: 12, issues: 28, build: 97, score: 91 },
                { name: 'Maria Garcia', commits: 74, lines: 3600, prs: 9, issues: 21, build: 94, score: 85 },
                { name: 'James Wilson', commits: 62, lines: 2800, prs: 7, issues: 15, build: 98, score: 78 },
                { name: 'Priya Patel', commits: 56, lines: 2400, prs: 8, issues: 19, build: 91, score: 74 },
                { name: 'Tom Brown', commits: 18, lines: 720, prs: 2, issues: 4, build: 75, score: 34 },
                { name: 'Lisa Kim', commits: 12, lines: 480, prs: 1, issues: 2, build: 68, score: 28 },
              ].map(dev => (
                <tr key={dev.name} style={dev.score < 50 ? { background: 'rgba(224,25,80,0.025)' } : {}}>
                  <td>
                    <div className="d-flex align-items-center gap-2">
                      <div style={{ width: 30, height: 30, borderRadius: 8, background: dev.score < 50 ? '#E01950' : '#27235C', display: 'flex', alignItems: 'center', justifyContent: 'center', color: 'white', fontWeight: 700, fontSize: 11 }}>
                        {dev.name.split(' ').map(w => w[0]).join('')}
                      </div>
                      <span style={{ fontWeight: 600, fontSize: 14 }}>{dev.name}</span>
                    </div>
                  </td>
                  <td>{dev.commits}</td>
                  <td>+{dev.lines.toLocaleString()}</td>
                  <td>{dev.prs}</td>
                  <td>{dev.issues}</td>
                  <td>
                    <span className={`status-badge ${dev.build >= 90 ? 'success' : dev.build >= 75 ? 'warning' : 'danger'}`}>{dev.build}%</span>
                  </td>
                  <td>
                    <div className="d-flex align-items-center gap-2">
                      <div className="progress-custom" style={{ width: 60 }}>
                        <div className="progress-fill" style={{ width: `${dev.score}%`, background: dev.score < 50 ? '#E01950' : undefined }} />
                      </div>
                      <span style={{ fontWeight: 700, fontSize: 13, color: dev.score < 50 ? '#E01950' : '#27235C' }}>{dev.score}</span>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
