import React, { useState, useEffect } from 'react';
import { Bar, Pie, Line } from 'react-chartjs-2';
import { Chart as ChartJS, ArcElement, CategoryScale, LinearScale, BarElement, LineElement, PointElement, Title, Tooltip, Legend, Filler } from 'chart.js';

ChartJS.register(ArcElement, CategoryScale, LinearScale, BarElement, LineElement, PointElement, Title, Tooltip, Legend, Filler);

const teamMembers = [
  { name: 'Alex Chen', role: 'Frontend', commits: 89, prs: 12, score: 91, avatar: 'AC', status: 'active' },
  { name: 'Maria Garcia', role: 'Backend', commits: 74, prs: 9, score: 85, avatar: 'MG', status: 'active' },
  { name: 'James Wilson', role: 'DevOps', commits: 62, prs: 7, score: 78, avatar: 'JW', status: 'active' },
  { name: 'Priya Patel', role: 'Full Stack', commits: 56, prs: 8, score: 74, avatar: 'PP', status: 'active' },
  { name: 'Tom Brown', role: 'Frontend', commits: 18, prs: 2, score: 34, avatar: 'TB', status: 'low' },
  { name: 'Lisa Kim', role: 'Backend', commits: 12, prs: 1, score: 28, avatar: 'LK', status: 'low' },
];

const prodData = {
  labels: teamMembers.map(m => m.name.split(' ')[0]),
  datasets: [{
    label: 'Productivity Score',
    data: teamMembers.map(m => m.score),
    backgroundColor: teamMembers.map(m => m.score < 50 ? '#E01950' : m.score < 75 ? '#f59e0b' : '#27235C'),
    borderRadius: 10,
  }]
};

const contribPie = {
  labels: teamMembers.map(m => m.name.split(' ')[0]),
  datasets: [{
    data: teamMembers.map(m => m.commits),
    backgroundColor: ['#27235C', '#97247E', '#E01950', '#f59e0b', '#22c55e', '#3b82f6'],
    borderWidth: 0,
  }]
};

const sprintVelocity = {
  labels: ['Sprint 1', 'Sprint 2', 'Sprint 3', 'Sprint 4', 'Sprint 5', 'Sprint 6'],
  datasets: [{
    label: 'Velocity',
    data: [42, 56, 48, 63, 71, 68],
    fill: true,
    backgroundColor: 'rgba(151,36,126,0.08)',
    borderColor: '#97247E',
    tension: 0.4,
    pointBackgroundColor: '#97247E',
    borderWidth: 2.5,
  }]
};

const chartOpts = {
  responsive: true, maintainAspectRatio: false,
  plugins: { legend: { display: false }, tooltip: { backgroundColor: '#27235C', padding: 12, cornerRadius: 10 } },
  scales: { x: { grid: { display: false }, border: { display: false } }, y: { grid: { color: '#f5f5f5' }, border: { display: false } } }
};

export default function ManagerDashboard() {
  const [anim, setAnim] = useState(false);
  useEffect(() => { setTimeout(() => setAnim(true), 100); }, []);

  const lowPerformers = teamMembers.filter(m => m.score < 50);

  return (
    <div>
      <div className="page-header">
        <div className="d-flex justify-content-between align-items-center flex-wrap gap-3">
          <div>
            <h1 className="page-title">Manager Dashboard</h1>
            <p className="page-subtitle">Team performance overview · Sprint 6 · April 2024</p>
          </div>
          <div className="d-flex gap-2">
            <button className="btn-outline-primary-custom"><i className="bi bi-download me-2" />Export</button>
            <button className="btn-gradient"><i className="bi bi-arrow-clockwise me-2" />Refresh</button>
          </div>
        </div>
      </div>

      {/* Low Performer Alerts */}
      {lowPerformers.length > 0 && (
        <div className="mb-4">
          {lowPerformers.map(dev => (
            <div key={dev.name} className="custom-alert danger mb-2">
              <i className="bi bi-exclamation-triangle-fill" style={{ fontSize: 16 }} />
              <div>
                <strong>{dev.name}</strong> is underperforming — Score: <strong>{dev.score}/100</strong>, only <strong>{dev.commits}</strong> commits this sprint.
                <span style={{ marginLeft: 12, fontSize: 12, cursor: 'pointer', textDecoration: 'underline' }}>View Details →</span>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* KPI Cards */}
      <div className="row g-3 mb-4">
        {[
          { label: 'Total Team Commits', value: teamMembers.reduce((a,m) => a+m.commits, 0), icon: 'bi-git', color: 'blue', trend: '+23%' },
          { label: 'Active Developers', value: `${teamMembers.filter(m=>m.status==='active').length}/${teamMembers.length}`, icon: 'bi-people-fill', color: 'purple', trend: `${teamMembers.filter(m=>m.score<50).length} at risk` },
          { label: 'Sprint Velocity', value: '68', icon: 'bi-speedometer2', color: 'green', trend: '+8 pts' },
          { label: 'Avg Score', value: Math.round(teamMembers.reduce((a,m) => a+m.score, 0) / teamMembers.length), icon: 'bi-bar-chart-fill', color: 'red', trend: '+5 pts' },
        ].map((kpi, i) => (
          <div key={kpi.label} className="col-6 col-lg-3">
            <div className="kpi-card" style={{ opacity: anim ? 1 : 0, transform: anim ? 'none' : 'translateY(20px)', transition: `all 0.5s ${i*0.1}s` }}>
              <div className={`kpi-icon ${kpi.color}`}>
                <i className={`bi ${kpi.icon}`} />
              </div>
              <div className="kpi-value">{kpi.value}</div>
              <div className="kpi-label">{kpi.label}</div>
              <div className="kpi-trend up mt-2">
                <i className="bi bi-arrow-up" />{kpi.trend}
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* Charts */}
      <div className="row g-3 mb-4">
        <div className="col-lg-6">
          <div className="chart-card">
            <div className="chart-card-header">
              <div>
                <div className="chart-card-title">Team Productivity Comparison</div>
                <div className="chart-card-sub">Score out of 100 · Red = needs attention</div>
              </div>
            </div>
            <div style={{ height: 240 }}>
              <Bar data={prodData} options={chartOpts} />
            </div>
          </div>
        </div>
        <div className="col-lg-3">
          <div className="chart-card">
            <div className="chart-card-header">
              <div>
                <div className="chart-card-title">Commit Distribution</div>
                <div className="chart-card-sub">By developer</div>
              </div>
            </div>
            <div style={{ height: 200 }}>
              <Pie data={contribPie} options={{ responsive: true, maintainAspectRatio: false, plugins: { legend: { position: 'bottom', labels: { boxWidth: 8, font: { size: 11 } } } } }} />
            </div>
          </div>
        </div>
        <div className="col-lg-3">
          <div className="chart-card">
            <div className="chart-card-header">
              <div>
                <div className="chart-card-title">Sprint Velocity</div>
                <div className="chart-card-sub">Last 6 sprints</div>
              </div>
            </div>
            <div style={{ height: 200 }}>
              <Line data={sprintVelocity} options={{ ...chartOpts, plugins: { ...chartOpts.plugins, legend: { display: false } } }} />
            </div>
          </div>
        </div>
      </div>

      {/* Team Table */}
      <div className="data-table">
        <div className="data-table-header">
          <div className="data-table-title">Team Members Overview</div>
          <button className="btn-gradient" style={{ padding: '7px 16px', fontSize: 13 }}>
            <i className="bi bi-person-plus me-1" />Add Developer
          </button>
        </div>
        <div className="table-responsive">
          <table className="table mb-0">
            <thead>
              <tr>
                <th>Developer</th>
                <th>Role</th>
                <th>Commits</th>
                <th>PRs</th>
                <th>Score</th>
                <th>Status</th>
                <th>Actions</th>
              </tr>
            </thead>
            <tbody>
              {teamMembers.map((dev, i) => (
                <tr key={dev.name} style={dev.score < 50 ? { background: 'rgba(224,25,80,0.025)' } : {}}>
                  <td>
                    <div className="d-flex align-items-center gap-3">
                      <div style={{
                        width: 36, height: 36, borderRadius: 10, fontWeight: 700, fontSize: 13,
                        background: dev.score < 50 ? 'linear-gradient(135deg, #E01950, #c01440)' : 'linear-gradient(135deg, #27235C, #97247E)',
                        display: 'flex', alignItems: 'center', justifyContent: 'center', color: 'white'
                      }}>{dev.avatar}</div>
                      <div>
                        <div style={{ fontWeight: 600, fontSize: 14 }}>{dev.name}</div>
                        <div style={{ fontSize: 11, color: '#aaa' }}>@{dev.name.toLowerCase().replace(' ', '.')}</div>
                      </div>
                    </div>
                  </td>
                  <td><span className="status-badge info">{dev.role}</span></td>
                  <td style={{ fontWeight: 600 }}>{dev.commits}</td>
                  <td>{dev.prs}</td>
                  <td>
                    <div className="d-flex align-items-center gap-2">
                      <div className="progress-custom" style={{ width: 60 }}>
                        <div className="progress-fill" style={{ width: `${dev.score}%`, background: dev.score < 50 ? '#E01950' : dev.score < 75 ? '#f59e0b' : 'linear-gradient(90deg, #27235C, #97247E)' }} />
                      </div>
                      <span style={{ fontSize: 13, fontWeight: 700, color: dev.score < 50 ? '#E01950' : '#27235C' }}>{dev.score}</span>
                    </div>
                  </td>
                  <td>
                    <span className={`status-badge ${dev.score < 50 ? 'danger' : 'success'}`}>
                      {dev.score < 50 ? '⚠ At Risk' : '✓ Active'}
                    </span>
                  </td>
                  <td>
                    <button className="btn-gradient" style={{ padding: '5px 12px', fontSize: 12 }}>View</button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
