import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';

export default function LoginPage() {
  const { setUser } = useAuth();
  const navigate = useNavigate();
  const [form, setForm] = useState({ email: '', password: '' });
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  const handleManagerLogin = async (e) => {
    e.preventDefault();
    setLoading(true);
    setError('');
    // Simulate API call
    setTimeout(() => {
      if (form.email && form.password) {
        const user = { id: 1, name: 'Sarah Johnson', email: form.email, role: 'MANAGER' };
        localStorage.setItem('token', 'mock-jwt-token-manager');
        localStorage.setItem('user', JSON.stringify(user));
        setUser(user);
        navigate('/manager');
      } else {
        setError('Invalid credentials. Please try again.');
      }
      setLoading(false);
    }, 1000);
  };

  const handleGitHubLogin = () => {
    setLoading(true);
    // Simulate GitHub OAuth
    setTimeout(() => {
      const user = { id: 2, name: 'Alex Chen', email: 'alex@github.com', role: 'DEVELOPER', avatar: 'AC' };
      localStorage.setItem('token', 'mock-github-oauth-token');
      localStorage.setItem('user', JSON.stringify(user));
      setUser(user);
      navigate('/developer');
    }, 1200);
  };

  return (
    <div className="login-page">
      {/* Left - Branding */}
      <div className="login-left">
        <div style={{ position: 'relative', zIndex: 1, textAlign: 'center' }}>
          <div style={{ marginBottom: 40 }}>
            <div style={{
              width: 72, height: 72,
              background: 'rgba(255,255,255,0.15)',
              borderRadius: 20,
              display: 'flex', alignItems: 'center', justifyContent: 'center',
              margin: '0 auto 20px',
              backdropFilter: 'blur(10px)',
              border: '1px solid rgba(255,255,255,0.2)'
            }}>
              <i className="bi bi-activity" style={{ fontSize: 36, color: 'white' }} />
            </div>
            <h1 style={{ color: 'white', fontSize: 36, fontWeight: 800, marginBottom: 12 }}>DevDash</h1>
            <p style={{ color: 'rgba(255,255,255,0.75)', fontSize: 16, lineHeight: 1.7, maxWidth: 340 }}>
              Track developer productivity, monitor GitHub Actions, and gain insights into your team's performance.
            </p>
          </div>

          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 16, maxWidth: 360 }}>
            {[
              { icon: 'bi-git', label: 'Git Integration', desc: 'Real-time commit tracking' },
              { icon: 'bi-people', label: 'Team Analytics', desc: 'Performance insights' },
              { icon: 'bi-lightning-charge', label: 'CI/CD Monitor', desc: 'GitHub Actions data' },
              { icon: 'bi-bar-chart-line', label: 'Productivity Score', desc: 'AI-driven metrics' },
            ].map(f => (
              <div key={f.label} style={{
                background: 'rgba(255,255,255,0.08)',
                borderRadius: 14,
                padding: '16px',
                border: '1px solid rgba(255,255,255,0.12)',
                textAlign: 'left',
                backdropFilter: 'blur(10px)'
              }}>
                <i className={`bi ${f.icon}`} style={{ fontSize: 22, color: 'rgba(255,255,255,0.9)', marginBottom: 8, display: 'block' }} />
                <div style={{ color: 'white', fontWeight: 700, fontSize: 13 }}>{f.label}</div>
                <div style={{ color: 'rgba(255,255,255,0.55)', fontSize: 11, marginTop: 2 }}>{f.desc}</div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Right - Login Form */}
      <div className="login-right">
        <div className="login-form-container">
          <div style={{ marginBottom: 36 }}>
            <h2 style={{ fontSize: 28, fontWeight: 800, color: '#27235C', marginBottom: 8 }}>Welcome back</h2>
            <p style={{ color: '#888', fontSize: 15 }}>Sign in to your productivity dashboard</p>
          </div>

          {/* GitHub Button */}
          <button className="github-btn" onClick={handleGitHubLogin} disabled={loading}>
            <svg width="20" height="20" viewBox="0 0 24 24" fill="white">
              <path d="M12 0C5.37 0 0 5.37 0 12c0 5.31 3.435 9.795 8.205 11.385.6.105.825-.255.825-.57 0-.285-.015-1.23-.015-2.235-3.015.555-3.795-.735-4.035-1.41-.135-.345-.72-1.41-1.23-1.695-.42-.225-1.02-.78-.015-.795.945-.015 1.62.87 1.845 1.23 1.08 1.815 2.805 1.305 3.495.99.105-.78.42-1.305.765-1.605-2.67-.3-5.46-1.335-5.46-5.925 0-1.305.465-2.385 1.23-3.225-.12-.3-.54-1.53.12-3.18 0 0 1.005-.315 3.3 1.23.96-.27 1.98-.405 3-.405s2.04.135 3 .405c2.295-1.56 3.3-1.23 3.3-1.23.66 1.65.24 2.88.12 3.18.765.84 1.23 1.905 1.23 3.225 0 4.605-2.805 5.625-5.475 5.925.435.375.81 1.095.81 2.22 0 1.605-.015 2.895-.015 3.3 0 .315.225.69.825.57A12.02 12.02 0 0024 12c0-6.63-5.37-12-12-12z" />
            </svg>
            Continue with GitHub
            <i className="bi bi-arrow-right ms-auto" />
          </button>

          <div className="divider">or sign in as manager</div>

          {error && (
            <div className="custom-alert danger mb-3">
              <i className="bi bi-exclamation-triangle-fill" />
              {error}
            </div>
          )}

          <form onSubmit={handleManagerLogin}>
            <div className="mb-3">
              <label style={{ fontSize: 13, fontWeight: 600, color: '#555', marginBottom: 6, display: 'block' }}>
                Email Address
              </label>
              <div style={{ position: 'relative' }}>
                <i className="bi bi-envelope" style={{ position: 'absolute', left: 14, top: '50%', transform: 'translateY(-50%)', color: '#aaa', fontSize: 15 }} />
                <input
                  type="email"
                  className="form-control-custom"
                  style={{ paddingLeft: 42 }}
                  placeholder="manager@company.com"
                  value={form.email}
                  onChange={e => setForm({ ...form, email: e.target.value })}
                  required
                />
              </div>
            </div>

            <div className="mb-4">
              <label style={{ fontSize: 13, fontWeight: 600, color: '#555', marginBottom: 6, display: 'block' }}>
                Password
              </label>
              <div style={{ position: 'relative' }}>
                <i className="bi bi-lock" style={{ position: 'absolute', left: 14, top: '50%', transform: 'translateY(-50%)', color: '#aaa', fontSize: 15 }} />
                <input
                  type="password"
                  className="form-control-custom"
                  style={{ paddingLeft: 42 }}
                  placeholder="••••••••"
                  value={form.password}
                  onChange={e => setForm({ ...form, password: e.target.value })}
                  required
                />
              </div>
            </div>

            <button
              type="submit"
              className="btn-gradient w-100 justify-content-center"
              style={{ padding: '13px', fontSize: 15 }}
              disabled={loading}
            >
              {loading ? (
                <>
                  <span className="spinner-border spinner-border-sm me-2" />
                  Signing in...
                </>
              ) : (
                <>
                  <i className="bi bi-shield-lock" />
                  Sign in as Manager
                </>
              )}
            </button>
          </form>

          <div style={{ marginTop: 28, textAlign: 'center', fontSize: 12, color: '#bbb' }}>
            Demo: Use any email + password for Manager, GitHub button for Developer
          </div>

          <div style={{ marginTop: 32, padding: '16px', background: '#f8f9ff', borderRadius: 12, border: '1px solid rgba(39,35,92,0.08)' }}>
            <div style={{ fontSize: 12, fontWeight: 700, color: '#27235C', marginBottom: 8 }}>🔐 Quick Demo Access</div>
            <div style={{ fontSize: 12, color: '#888', lineHeight: 1.7 }}>
              <strong>Manager:</strong> admin@devdash.io / any password<br />
              <strong>Developer:</strong> Click "Continue with GitHub"
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
