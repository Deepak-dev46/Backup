import React, { useState, useEffect } from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import 'bootstrap/dist/css/bootstrap.min.css';
import 'bootstrap-icons/font/bootstrap-icons.css';
import './styles/global.css';

import LoginPage from './pages/LoginPage';
import DeveloperDashboard from './pages/developer/DeveloperDashboard';
import DeveloperRepositories from './pages/developer/DeveloperRepositories';
import DeveloperMetrics from './pages/developer/DeveloperMetrics';
import ManagerDashboard from './pages/manager/ManagerDashboard';
import TeamManagement from './pages/manager/TeamManagement';
import DeveloperInsights from './pages/manager/DeveloperInsights';
import ReportsPage from './pages/manager/ReportsPage';
import Layout from './components/layout/Layout';
import { AuthContext } from './context/AuthContext';

function App() {
  const [user, setUser] = useState(null);
  const [darkMode, setDarkMode] = useState(false);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const token = localStorage.getItem('token');
    const userData = localStorage.getItem('user');
    if (token && userData) {
      setUser(JSON.parse(userData));
    }
    setLoading(false);
  }, []);

  useEffect(() => {
    document.body.classList.toggle('dark-mode', darkMode);
  }, [darkMode]);

  if (loading) return (
    <div className="loading-overlay">
      <div className="spinner-gradient"></div>
    </div>
  );

  const isAuthenticated = !!user;
  const isManager = user?.role === 'MANAGER';
  const isDeveloper = user?.role === 'DEVELOPER';

  return (
    <AuthContext.Provider value={{ user, setUser, darkMode, setDarkMode }}>
      <Router>
        <Routes>
          <Route path="/login" element={!isAuthenticated ? <LoginPage /> : <Navigate to={isManager ? '/manager' : '/developer'} />} />

          {/* Developer Routes */}
          <Route path="/developer" element={isAuthenticated && isDeveloper ? <Layout /> : <Navigate to="/login" />}>
            <Route index element={<DeveloperDashboard />} />
            <Route path="repositories" element={<DeveloperRepositories />} />
            <Route path="metrics" element={<DeveloperMetrics />} />
          </Route>

          {/* Manager Routes */}
          <Route path="/manager" element={isAuthenticated && isManager ? <Layout /> : <Navigate to="/login" />}>
            <Route index element={<ManagerDashboard />} />
            <Route path="teams" element={<TeamManagement />} />
            <Route path="insights" element={<DeveloperInsights />} />
            <Route path="reports" element={<ReportsPage />} />
          </Route>

          <Route path="/" element={<Navigate to={isAuthenticated ? (isManager ? '/manager' : '/developer') : '/login'} />} />
          <Route path="*" element={<Navigate to="/" />} />
        </Routes>
      </Router>
    </AuthContext.Provider>
  );
}

export default App;
