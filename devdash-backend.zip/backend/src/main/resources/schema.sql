-- ============================================================
-- DevDash - MySQL Database Schema
-- Run this script to initialize the database manually
-- (Spring Boot auto-creates tables via JPA when ddl-auto=update)
-- ============================================================

CREATE DATABASE IF NOT EXISTS devdash_db
  CHARACTER SET utf8mb4
  COLLATE utf8mb4_unicode_ci;

USE devdash_db;

-- ── Users ─────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS users (
    id                 BIGINT          NOT NULL AUTO_INCREMENT,
    name               VARCHAR(100)    NOT NULL,
    email              VARCHAR(150)    NOT NULL UNIQUE,
    password           VARCHAR(255),
    role               ENUM('DEVELOPER','MANAGER','ADMIN') NOT NULL DEFAULT 'DEVELOPER',
    github_id          VARCHAR(50),
    github_username    VARCHAR(100),
    avatar_url         VARCHAR(500),
    access_token       VARCHAR(1000),
    productivity_score INT             DEFAULT 0,
    is_active          TINYINT(1)      DEFAULT 1,
    created_at         DATETIME        DEFAULT CURRENT_TIMESTAMP,
    updated_at         DATETIME        DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    INDEX idx_email (email),
    INDEX idx_github_id (github_id),
    INDEX idx_role (role)
);

-- ── Teams ─────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS teams (
    id          BIGINT          NOT NULL AUTO_INCREMENT,
    name        VARCHAR(100)    NOT NULL,
    description VARCHAR(500),
    manager_id  BIGINT          NOT NULL,
    is_active   TINYINT(1)      DEFAULT 1,
    created_at  DATETIME        DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    CONSTRAINT fk_team_manager FOREIGN KEY (manager_id) REFERENCES users(id) ON DELETE RESTRICT,
    INDEX idx_manager (manager_id)
);

-- ── Team Members ──────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS team_members (
    id         BIGINT   NOT NULL AUTO_INCREMENT,
    team_id    BIGINT   NOT NULL,
    user_id    BIGINT   NOT NULL,
    joined_at  DATETIME DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    UNIQUE KEY uq_team_user (team_id, user_id),
    CONSTRAINT fk_tm_team FOREIGN KEY (team_id) REFERENCES teams(id) ON DELETE CASCADE,
    CONSTRAINT fk_tm_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

-- ── Repositories ──────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS repositories (
    id                 BIGINT          NOT NULL AUTO_INCREMENT,
    user_id            BIGINT          NOT NULL,
    repo_name          VARCHAR(200)    NOT NULL,
    full_name          VARCHAR(300),
    description        TEXT,
    language           VARCHAR(50),
    stars_count        INT             DEFAULT 0,
    forks_count        INT             DEFAULT 0,
    open_issues_count  INT             DEFAULT 0,
    is_private         TINYINT(1)      DEFAULT 0,
    default_branch     VARCHAR(100)    DEFAULT 'main',
    html_url           VARCHAR(500),
    last_commit_at     DATETIME,
    created_at         DATETIME        DEFAULT CURRENT_TIMESTAMP,
    updated_at         DATETIME        DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    CONSTRAINT fk_repo_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    INDEX idx_user_repo (user_id),
    INDEX idx_full_name (full_name)
);

-- ── Commits ───────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS commits (
    id             BIGINT       NOT NULL AUTO_INCREMENT,
    repo_id        BIGINT       NOT NULL,
    author_id      BIGINT,
    commit_sha     VARCHAR(40),
    commit_message VARCHAR(500),
    commit_count   INT          DEFAULT 1,
    additions      INT          DEFAULT 0,
    deletions      INT          DEFAULT 0,
    date           DATE,
    committed_at   DATETIME,
    PRIMARY KEY (id),
    CONSTRAINT fk_commit_repo   FOREIGN KEY (repo_id)   REFERENCES repositories(id) ON DELETE CASCADE,
    CONSTRAINT fk_commit_author FOREIGN KEY (author_id) REFERENCES users(id) ON DELETE SET NULL,
    INDEX idx_commit_repo   (repo_id),
    INDEX idx_commit_author (author_id),
    INDEX idx_commit_date   (date)
);

-- ── Pull Requests ─────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS pull_requests (
    id            BIGINT       NOT NULL AUTO_INCREMENT,
    repo_id       BIGINT       NOT NULL,
    author_id     BIGINT,
    pr_number     INT,
    title         VARCHAR(500),
    status        ENUM('OPEN','MERGED','CLOSED') DEFAULT 'OPEN',
    additions     INT          DEFAULT 0,
    deletions     INT          DEFAULT 0,
    changed_files INT          DEFAULT 0,
    merged_at     DATETIME,
    closed_at     DATETIME,
    created_at    DATETIME     DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    CONSTRAINT fk_pr_repo   FOREIGN KEY (repo_id)   REFERENCES repositories(id) ON DELETE CASCADE,
    CONSTRAINT fk_pr_author FOREIGN KEY (author_id) REFERENCES users(id) ON DELETE SET NULL,
    INDEX idx_pr_repo   (repo_id),
    INDEX idx_pr_author (author_id),
    INDEX idx_pr_status (status)
);

-- ── GitHub Actions Data ───────────────────────────────────────
CREATE TABLE IF NOT EXISTS actions_data (
    id               BIGINT       NOT NULL AUTO_INCREMENT,
    repo_id          BIGINT       NOT NULL,
    workflow_name    VARCHAR(200),
    run_id           BIGINT,
    build_status     ENUM('SUCCESS','FAILURE','IN_PROGRESS','CANCELLED','SKIPPED') NOT NULL,
    branch           VARCHAR(100),
    run_time_seconds BIGINT,
    triggered_by     VARCHAR(100),
    commit_sha       VARCHAR(40),
    completed_at     DATETIME,
    created_at       DATETIME     DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    CONSTRAINT fk_actions_repo FOREIGN KEY (repo_id) REFERENCES repositories(id) ON DELETE CASCADE,
    INDEX idx_actions_repo   (repo_id),
    INDEX idx_actions_status (build_status),
    INDEX idx_actions_branch (branch)
);

-- ── Seed Data (demo) ──────────────────────────────────────────
-- Default manager account (password: Admin@123)
INSERT IGNORE INTO users (name, email, password, role, is_active) VALUES
  ('Sarah Johnson', 'admin@devdash.io',
   '$2a$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2uheWG/igi.',
   'MANAGER', 1),
  ('Alex Chen',    'alex@dev.io',
   '$2a$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2uheWG/igi.',
   'DEVELOPER', 1),
  ('Maria Garcia', 'maria@dev.io',
   '$2a$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2uheWG/igi.',
   'DEVELOPER', 1);

-- ============================================================
-- END OF SCHEMA
-- ============================================================
