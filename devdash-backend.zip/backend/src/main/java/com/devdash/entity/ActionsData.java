package com.devdash.entity;

import jakarta.persistence.*;
import lombok.*;
import org.hibernate.annotations.CreationTimestamp;

import java.time.LocalDateTime;

@Entity
@Table(name = "actions_data")
@Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder
public class ActionsData {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "repo_id", nullable = false)
    private Repository repository;

    @Column(name = "workflow_name")
    private String workflowName;

    @Column(name = "run_id")
    private Long runId;

    @Enumerated(EnumType.STRING)
    @Column(name = "build_status")
    private BuildStatus buildStatus;

    @Column(name = "branch")
    private String branch;

    @Column(name = "run_time_seconds")
    private Long runTimeSeconds;

    @Column(name = "triggered_by")
    private String triggeredBy;

    @Column(name = "commit_sha", length = 40)
    private String commitSha;

    @CreationTimestamp
    @Column(name = "created_at", updatable = false)
    private LocalDateTime createdAt;

    @Column(name = "completed_at")
    private LocalDateTime completedAt;

    public enum BuildStatus {
        SUCCESS, FAILURE, IN_PROGRESS, CANCELLED, SKIPPED
    }
}
