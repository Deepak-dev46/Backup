package com.devdash.entity;

import jakarta.persistence.*;
import lombok.*;

import java.time.LocalDate;
import java.time.LocalDateTime;

@Entity
@Table(name = "commits")
@Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder
public class Commit {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "repo_id", nullable = false)
    private Repository repository;

    @Column(name = "commit_sha", length = 40)
    private String commitSha;

    @Column(name = "commit_message", length = 500)
    private String commitMessage;

    @Column(name = "commit_count")
    @Builder.Default
    private Integer commitCount = 1;

    @Column(name = "additions")
    @Builder.Default
    private Integer additions = 0;

    @Column(name = "deletions")
    @Builder.Default
    private Integer deletions = 0;

    @Column(name = "date")
    private LocalDate date;

    @Column(name = "committed_at")
    private LocalDateTime committedAt;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "author_id")
    private User author;
}
