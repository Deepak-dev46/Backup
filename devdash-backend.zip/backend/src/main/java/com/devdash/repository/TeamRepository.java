package com.devdash.repository;

import com.devdash.entity.Team;
import com.devdash.entity.User;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface TeamRepository extends JpaRepository<Team, Long> {
    List<Team> findByManager(User manager);
    List<Team> findByIsActiveTrue();

    @Query("SELECT t FROM Team t LEFT JOIN FETCH t.members WHERE t.id = :id")
    Team findByIdWithMembers(Long id);
}
