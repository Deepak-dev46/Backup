package com.devdash.dto;

import com.devdash.entity.User;
import lombok.*;

import java.time.LocalDateTime;
import java.util.List;

// ── User ─────────────────────────────────────────────────────
@Getter @Setter @Builder @NoArgsConstructor @AllArgsConstructor
class UserDto {
    private Long id;
    private String name;
    private String email;
    private String role;
    private String githubUsername;
    private String avatarUrl;
    private Integer productivityScore;
    private Boolean isActive;
    private LocalDateTime createdAt;
}

// ── Team ─────────────────────────────────────────────────────
@Getter @Setter @Builder @NoArgsConstructor @AllArgsConstructor
class TeamDto {
    private Long id;
    private String name;
    private String description;
    private Long managerId;
    private String managerName;
    private List<MemberDto> members;
    private Boolean isActive;
    private LocalDateTime createdAt;
}

@Getter @Setter @Builder @NoArgsConstructor @AllArgsConstructor
class MemberDto {
    private Long userId;
    private String name;
    private String email;
    private String avatarUrl;
    private Integer productivityScore;
    private LocalDateTime joinedAt;
}

// ── Repository ───────────────────────────────────────────────
@Getter @Setter @Builder @NoArgsConstructor @AllArgsConstructor
class RepositoryDto {
    private Long id;
    private String repoName;
    private String fullName;
    private String description;
    private String language;
    private Integer starsCount;
    private Integer forksCount;
    private Integer openIssuesCount;
    private Boolean isPrivate;
    private String defaultBranch;
    private String htmlUrl;
    private LocalDateTime lastCommitAt;
    private Long totalCommits;
}

// ── Metrics ──────────────────────────────────────────────────
@Getter @Setter @Builder @NoArgsConstructor @AllArgsConstructor
class DeveloperMetricsDto {
    private Long userId;
    private String name;
    private Long totalCommits;
    private Long mergedPrs;
    private Long openPrs;
    private Long totalPrs;
    private Long issuesResolved;
    private Long totalAdditions;
    private Long totalDeletions;
    private Integer productivityScore;
    private Double prMergeRate;
    private List<DailyCommitDto> weeklyActivity;
}

@Getter @Setter @Builder @NoArgsConstructor @AllArgsConstructor
class DailyCommitDto {
    private String date;
    private Long count;
}

// ── GitHub Webhook Payload ────────────────────────────────────
@Getter @Setter
class WebhookPayload {
    private String action;
    private WorkflowRun workflow_run;
    private Repository repository;

    @Getter @Setter
    public static class WorkflowRun {
        private Long id;
        private String name;
        private String status;
        private String conclusion;
        private String head_branch;
        private String head_sha;
        private Long run_number;
        private String created_at;
        private String updated_at;
    }

    @Getter @Setter
    public static class Repository {
        private Long id;
        private String full_name;
        private String name;
    }
}
