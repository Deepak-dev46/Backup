package com.devdash.dto;

import com.devdash.entity.User;
import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;
import lombok.*;

public class AuthDto {

    @Getter @Setter
    public static class LoginRequest {
        @NotBlank @Email
        private String email;
        @NotBlank @Size(min = 6)
        private String password;
    }

    @Getter @Setter
    public static class RegisterRequest {
        @NotBlank
        private String name;
        @NotBlank @Email
        private String email;
        @NotBlank @Size(min = 6)
        private String password;
        private User.Role role = User.Role.DEVELOPER;
    }

    @Getter @Setter @Builder @NoArgsConstructor @AllArgsConstructor
    public static class AuthResponse {
        private String token;
        private String refreshToken;
        private String type = "Bearer";
        private Long id;
        private String name;
        private String email;
        private String role;
        private String avatarUrl;
        private String githubUsername;
    }

    @Getter @Setter
    public static class RefreshTokenRequest {
        @NotBlank
        private String refreshToken;
    }
}
