package com.devdash.controller;

import com.devdash.entity.ActionsData;
import com.devdash.entity.Repository;
import com.devdash.repository.ActionsDataRepository;
import com.devdash.repository.RepositoryRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDateTime;
import java.util.Map;

@RestController
@RequestMapping("/api/webhook")
public class WebhookController {

    private static final Logger log = LoggerFactory.getLogger(WebhookController.class);

    @Autowired RepositoryRepository repoRepository;
    @Autowired ActionsDataRepository actionsDataRepository;

    /**
     * GitHub Actions webhook receiver.
     * Configure in GitHub: Settings > Webhooks > Payload URL = https://your-domain/api/webhook/github
     * Content type: application/json
     * Events: Workflow runs
     */
    @PostMapping("/github")
    public ResponseEntity<?> handleGitHubWebhook(
            @RequestHeader(value = "X-GitHub-Event", defaultValue = "") String event,
            @RequestHeader(value = "X-Hub-Signature-256", defaultValue = "") String signature,
            @RequestBody Map<String, Object> payload) {

        log.info("Received GitHub webhook event: {}", event);

        switch (event) {
            case "workflow_run" -> handleWorkflowRun(payload);
            case "push"         -> handlePush(payload);
            case "pull_request" -> handlePullRequest(payload);
            case "ping"         -> log.info("GitHub webhook ping received");
            default             -> log.debug("Unhandled event: {}", event);
        }

        return ResponseEntity.ok(Map.of("status", "received"));
    }

    @SuppressWarnings("unchecked")
    private void handleWorkflowRun(Map<String, Object> payload) {
        try {
            Map<String, Object> run = (Map<String, Object>) payload.get("workflow_run");
            Map<String, Object> repoData = (Map<String, Object>) payload.get("repository");
            if (run == null || repoData == null) return;

            String fullName = (String) repoData.get("full_name");
            Repository repo = repoRepository.findByFullName(fullName).orElse(null);
            if (repo == null) {
                log.warn("Repository not found for webhook: {}", fullName);
                return;
            }

            String conclusion = (String) run.getOrDefault("conclusion", "");
            String status    = (String) run.getOrDefault("status", "");
            ActionsData.BuildStatus buildStatus;
            if ("success".equalsIgnoreCase(conclusion))         buildStatus = ActionsData.BuildStatus.SUCCESS;
            else if ("failure".equalsIgnoreCase(conclusion))    buildStatus = ActionsData.BuildStatus.FAILURE;
            else if ("cancelled".equalsIgnoreCase(conclusion))  buildStatus = ActionsData.BuildStatus.CANCELLED;
            else if ("in_progress".equalsIgnoreCase(status))    buildStatus = ActionsData.BuildStatus.IN_PROGRESS;
            else                                                 buildStatus = ActionsData.BuildStatus.SKIPPED;

            Object runIdObj = run.get("id");
            Long runId = runIdObj != null ? Long.valueOf(runIdObj.toString()) : null;

            ActionsData data = ActionsData.builder()
                    .repository(repo)
                    .workflowName((String) run.getOrDefault("name", "Unknown"))
                    .runId(runId)
                    .buildStatus(buildStatus)
                    .branch((String) run.getOrDefault("head_branch", "main"))
                    .commitSha((String) run.getOrDefault("head_sha", ""))
                    .completedAt(LocalDateTime.now())
                    .build();

            actionsDataRepository.save(data);
            log.info("Saved Actions data for {}: {}", fullName, buildStatus);
        } catch (Exception e) {
            log.error("Error processing workflow_run webhook: {}", e.getMessage());
        }
    }

    private void handlePush(Map<String, Object> payload) {
        log.info("Push event received – commits: {}",
                ((java.util.List<?>) payload.getOrDefault("commits", java.util.List.of())).size());
    }

    private void handlePullRequest(Map<String, Object> payload) {
        String action = (String) payload.getOrDefault("action", "");
        log.info("Pull Request event: {}", action);
    }
}
