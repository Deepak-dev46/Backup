package com.devdash.service;

import com.devdash.entity.*;
import com.devdash.repository.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.util.*;

@Service
public class MetricsService {

    private static final Logger log = LoggerFactory.getLogger(MetricsService.class);

    @Autowired UserRepository userRepository;
    @Autowired CommitRepository commitRepository;
    @Autowired PullRequestRepository pullRequestRepository;
    @Autowired RepositoryRepository repositoryRepository;
    @Autowired ActionsDataRepository actionsDataRepository;

    // ── Developer Metrics ─────────────────────────────────────
    public Map<String, Object> getDeveloperMetrics(User user) {
        Long totalCommits  = Optional.ofNullable(commitRepository.countTotalCommitsByAuthor(user)).orElse(0L);
        Long mergedPrs     = Optional.ofNullable(pullRequestRepository.countMergedByAuthor(user)).orElse(0L);
        Long totalPrs      = Optional.ofNullable(pullRequestRepository.countTotalByAuthor(user)).orElse(0L);
        Long openPrs       = totalPrs - mergedPrs;

        Object[] addDel = commitRepository.findTotalAdditionsAndDeletionsByAuthor(user);
        long totalAdditions = addDel != null && addDel[0] != null ? ((Number) addDel[0]).longValue() : 0L;
        long totalDeletions = addDel != null && addDel[1] != null ? ((Number) addDel[1]).longValue() : 0L;

        double prMergeRate  = totalPrs > 0 ? (double) mergedPrs / totalPrs * 100 : 0;
        int score           = calculateProductivityScore(totalCommits, mergedPrs, totalPrs, totalAdditions);

        // Weekly activity (last 7 days)
        LocalDate end   = LocalDate.now();
        LocalDate start = end.minusDays(6);
        List<Map<String, Object>> weeklyActivity = getDailyCommitActivity(user, start, end);

        Map<String, Object> metrics = new HashMap<>();
        metrics.put("userId",          user.getId());
        metrics.put("name",            user.getName());
        metrics.put("totalCommits",    totalCommits);
        metrics.put("mergedPrs",       mergedPrs);
        metrics.put("openPrs",         openPrs);
        metrics.put("totalPrs",        totalPrs);
        metrics.put("totalAdditions",  totalAdditions);
        metrics.put("totalDeletions",  totalDeletions);
        metrics.put("prMergeRate",     Math.round(prMergeRate * 10.0) / 10.0);
        metrics.put("productivityScore", score);
        metrics.put("weeklyActivity",  weeklyActivity);
        metrics.put("repositories",    repositoryRepository.findByUser(user).size());
        return metrics;
    }

    // ── Daily commit activity chart data ─────────────────────
    public List<Map<String, Object>> getDailyCommitActivity(User user, LocalDate start, LocalDate end) {
        List<Object[]> raw = commitRepository.findDailyCommitCountByAuthor(user);
        Map<LocalDate, Long> byDate = new LinkedHashMap<>();
        for (Object[] row : raw) {
            if (row[0] instanceof LocalDate d) byDate.put(d, ((Number) row[1]).longValue());
        }

        List<Map<String, Object>> result = new ArrayList<>();
        for (LocalDate d = start; !d.isAfter(end); d = d.plusDays(1)) {
            result.add(Map.of("date", d.toString(), "count", byDate.getOrDefault(d, 0L)));
        }
        return result;
    }

    // ── Team metrics (for manager) ────────────────────────────
    public Map<String, Object> getTeamMetrics(User manager) {
        List<User> developers = userRepository.findByRole(User.Role.DEVELOPER);

        long totalCommits = 0;
        long totalPrs     = 0;
        int  activeDevs   = 0;
        List<Map<String, Object>> devMetrics = new ArrayList<>();

        for (User dev : developers) {
            Long commits = Optional.ofNullable(commitRepository.countTotalCommitsByAuthor(dev)).orElse(0L);
            Long prs     = Optional.ofNullable(pullRequestRepository.countTotalByAuthor(dev)).orElse(0L);
            totalCommits += commits;
            totalPrs     += prs;
            if (commits > 0) activeDevs++;

            devMetrics.add(Map.of(
                "id",    dev.getId(),
                "name",  dev.getName(),
                "commits", commits,
                "prs",   prs,
                "score", dev.getProductivityScore() != null ? dev.getProductivityScore() : 0
            ));
        }

        Map<String, Object> result = new HashMap<>();
        result.put("totalDevelopers",  developers.size());
        result.put("activeDevelopers", activeDevs);
        result.put("totalCommits",     totalCommits);
        result.put("totalPrs",         totalPrs);
        result.put("developers",       devMetrics);
        result.put("atRiskCount",      userRepository.findLowPerformingDevelopers().size());
        return result;
    }

    // ── Leaderboard ───────────────────────────────────────────
    public List<Map<String, Object>> getLeaderboard() {
        return userRepository.findTopDevelopersByScore().stream().map(u -> Map.of(
            "id",    (Object) u.getId(),
            "name",  u.getName(),
            "score", u.getProductivityScore() != null ? u.getProductivityScore() : 0,
            "avatar", u.getAvatarUrl() != null ? u.getAvatarUrl() : ""
        )).toList();
    }

    // ── Productivity Score Algorithm ──────────────────────────
    /**
     * Score 0-100 based on:
     *   40% commit frequency
     *   35% PR merge rate
     *   25% code volume (additions)
     */
    public int calculateProductivityScore(long commits, long mergedPrs,
                                          long totalPrs, long additions) {
        // Commit score: 40pts, ~60 commits/month = full score
        double commitScore   = Math.min(commits / 60.0, 1.0) * 40;
        // PR score: 35pts
        double prScore       = totalPrs > 0 ? ((double) mergedPrs / totalPrs) * 35 : 0;
        // Code volume score: 25pts, ~5000 additions = full score
        double volumeScore   = Math.min(additions / 5000.0, 1.0) * 25;

        int score = (int) Math.round(commitScore + prScore + volumeScore);
        return Math.max(0, Math.min(100, score));
    }

    // ── Scheduled: recalculate all scores every night ─────────
    @Scheduled(cron = "0 0 2 * * *")  // 2 AM daily
    public void recalculateAllScores() {
        log.info("Starting scheduled productivity score recalculation...");
        List<User> developers = userRepository.findByRole(User.Role.DEVELOPER);
        developers.forEach(dev -> {
            Long commits   = Optional.ofNullable(commitRepository.countTotalCommitsByAuthor(dev)).orElse(0L);
            Long mergedPrs = Optional.ofNullable(pullRequestRepository.countMergedByAuthor(dev)).orElse(0L);
            Long totalPrs  = Optional.ofNullable(pullRequestRepository.countTotalByAuthor(dev)).orElse(0L);
            Object[] ad    = commitRepository.findTotalAdditionsAndDeletionsByAuthor(dev);
            long additions = ad != null && ad[0] != null ? ((Number) ad[0]).longValue() : 0L;

            int score = calculateProductivityScore(commits, mergedPrs, totalPrs, additions);
            dev.setProductivityScore(score);
            userRepository.save(dev);
        });
        log.info("Score recalculation complete for {} developers.", developers.size());
    }
}
