package com.devdash.controller;

import com.devdash.entity.User;
import com.devdash.repository.*;
import com.devdash.service.MetricsService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDate;
import java.util.*;

@RestController
@RequestMapping("/api/metrics")
public class MetricsController {

    @Autowired MetricsService metricsService;
    @Autowired UserRepository userRepository;

    // GET current developer's own metrics
    @GetMapping("/me")
    public ResponseEntity<?> getMyMetrics(Authentication auth) {
        User user = userRepository.findByEmail(auth.getName())
                .orElseThrow(() -> new RuntimeException("User not found"));
        return ResponseEntity.ok(metricsService.getDeveloperMetrics(user));
    }

    // GET weekly activity for current user
    @GetMapping("/me/weekly")
    public ResponseEntity<?> getWeeklyActivity(Authentication auth) {
        User user = userRepository.findByEmail(auth.getName())
                .orElseThrow(() -> new RuntimeException("User not found"));
        LocalDate end = LocalDate.now();
        LocalDate start = end.minusDays(6);
        return ResponseEntity.ok(metricsService.getDailyCommitActivity(user, start, end));
    }

    // GET metrics for a specific developer (managers only)
    @GetMapping("/developer/{userId}")
    @PreAuthorize("hasRole('MANAGER') or hasRole('ADMIN')")
    public ResponseEntity<?> getDeveloperMetrics(@PathVariable Long userId) {
        User user = userRepository.findById(userId)
                .orElseThrow(() -> new RuntimeException("User not found"));
        return ResponseEntity.ok(metricsService.getDeveloperMetrics(user));
    }

    // GET team-wide metrics (managers only)
    @GetMapping("/team")
    @PreAuthorize("hasRole('MANAGER') or hasRole('ADMIN')")
    public ResponseEntity<?> getTeamMetrics(Authentication auth) {
        User manager = userRepository.findByEmail(auth.getName())
                .orElseThrow(() -> new RuntimeException("User not found"));
        return ResponseEntity.ok(metricsService.getTeamMetrics(manager));
    }

    // GET productivity leaderboard
    @GetMapping("/leaderboard")
    @PreAuthorize("hasRole('MANAGER') or hasRole('ADMIN')")
    public ResponseEntity<?> getLeaderboard() {
        return ResponseEntity.ok(metricsService.getLeaderboard());
    }

    // POST recalculate scores
    @PostMapping("/recalculate")
    @PreAuthorize("hasRole('MANAGER') or hasRole('ADMIN')")
    public ResponseEntity<?> recalculateScores() {
        metricsService.recalculateAllScores();
        return ResponseEntity.ok(Map.of("message", "Scores recalculated successfully"));
    }
}
