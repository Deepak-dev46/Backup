package com.devdash.controller;

import com.devdash.entity.Repository;
import com.devdash.entity.User;
import com.devdash.repository.RepositoryRepository;
import com.devdash.repository.UserRepository;
import com.devdash.service.GitHubService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;

import java.util.*;

@RestController
@RequestMapping("/api/repos")
public class RepositoryController {

    @Autowired RepositoryRepository repoRepository;
    @Autowired UserRepository userRepository;
    @Autowired GitHubService gitHubService;

    // GET current user's repos
    @GetMapping
    public ResponseEntity<?> getMyRepos(Authentication auth) {
        User user = userRepository.findByEmail(auth.getName())
                .orElseThrow(() -> new RuntimeException("User not found"));
        List<Repository> repos = repoRepository.findByUserOrderByLastCommitAtDesc(user);
        return ResponseEntity.ok(repos.stream().map(this::toDto).toList());
    }

    // GET repo by id
    @GetMapping("/{id}")
    public ResponseEntity<?> getRepo(@PathVariable Long id) {
        return repoRepository.findById(id)
                .map(r -> ResponseEntity.ok(toDto(r)))
                .orElse(ResponseEntity.notFound().build());
    }

    // POST sync repos from GitHub
    @PostMapping("/sync")
    public ResponseEntity<?> syncFromGitHub(Authentication auth) {
        User user = userRepository.findByEmail(auth.getName())
                .orElseThrow(() -> new RuntimeException("User not found"));
        try {
            List<Repository> synced = gitHubService.syncUserRepositories(user);
            return ResponseEntity.ok(Map.of(
                "message", "Sync successful",
                "count", synced.size(),
                "repositories", synced.stream().map(this::toDto).toList()
            ));
        } catch (Exception e) {
            return ResponseEntity.status(500).body(Map.of("error", "GitHub sync failed: " + e.getMessage()));
        }
    }

    // GET specific repo stats
    @GetMapping("/{id}/stats")
    public ResponseEntity<?> getRepoStats(@PathVariable Long id) {
        Repository repo = repoRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Repo not found"));
        return ResponseEntity.ok(Map.of(
            "commits", repo.getCommits() != null ? repo.getCommits().size() : 0,
            "pullRequests", repo.getPullRequests() != null ? repo.getPullRequests().size() : 0,
            "actions", repo.getActionsData() != null ? repo.getActionsData().size() : 0
        ));
    }

    private Map<String, Object> toDto(Repository r) {
        Map<String, Object> dto = new HashMap<>();
        dto.put("id", r.getId());
        dto.put("repoName", r.getRepoName());
        dto.put("fullName", r.getFullName() != null ? r.getFullName() : r.getRepoName());
        dto.put("description", r.getDescription() != null ? r.getDescription() : "");
        dto.put("language", r.getLanguage() != null ? r.getLanguage() : "Unknown");
        dto.put("starsCount", r.getStarsCount());
        dto.put("forksCount", r.getForksCount());
        dto.put("openIssuesCount", r.getOpenIssuesCount());
        dto.put("isPrivate", r.getIsPrivate());
        dto.put("defaultBranch", r.getDefaultBranch());
        dto.put("htmlUrl", r.getHtmlUrl() != null ? r.getHtmlUrl() : "");
        dto.put("lastCommitAt", r.getLastCommitAt());
        return dto;
    }
}
