package com.devdash.controller;

import com.devdash.entity.*;
import com.devdash.repository.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;

import java.util.*;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/api/teams")
@PreAuthorize("hasRole('MANAGER') or hasRole('ADMIN')")
public class TeamController {

    @Autowired TeamRepository teamRepository;
    @Autowired UserRepository userRepository;

    // GET all teams
    @GetMapping
    public ResponseEntity<?> getAllTeams() {
        return ResponseEntity.ok(teamRepository.findByIsActiveTrue().stream()
                .map(this::toDto).toList());
    }

    // GET team by id
    @GetMapping("/{id}")
    public ResponseEntity<?> getTeam(@PathVariable Long id) {
        return teamRepository.findById(id)
                .map(t -> ResponseEntity.ok(toDto(t)))
                .orElse(ResponseEntity.notFound().build());
    }

    // POST create team
    @PostMapping
    public ResponseEntity<?> createTeam(@RequestBody Map<String, Object> body,
                                        Authentication auth) {
        User manager = userRepository.findByEmail(auth.getName())
                .orElseThrow(() -> new RuntimeException("User not found"));

        Team team = Team.builder()
                .name((String) body.get("name"))
                .description((String) body.getOrDefault("description", ""))
                .manager(manager)
                .isActive(true)
                .build();

        Team saved = teamRepository.save(team);

        // Add initial members if provided
        if (body.containsKey("memberIds")) {
            List<?> ids = (List<?>) body.get("memberIds");
            ids.forEach(rawId -> {
                Long uid = Long.valueOf(rawId.toString());
                userRepository.findById(uid).ifPresent(u -> {
                    TeamMember tm = TeamMember.builder().team(saved).user(u).build();
                    saved.getMembers().add(tm);
                });
            });
            teamRepository.save(saved);
        }

        return ResponseEntity.ok(toDto(saved));
    }

    // PUT update team
    @PutMapping("/{id}")
    public ResponseEntity<?> updateTeam(@PathVariable Long id,
                                        @RequestBody Map<String, String> body) {
        Team team = teamRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Team not found"));
        if (body.containsKey("name")) team.setName(body.get("name"));
        if (body.containsKey("description")) team.setDescription(body.get("description"));
        teamRepository.save(team);
        return ResponseEntity.ok(toDto(team));
    }

    // POST add member
    @PostMapping("/{teamId}/members/{userId}")
    public ResponseEntity<?> addMember(@PathVariable Long teamId, @PathVariable Long userId) {
        Team team = teamRepository.findById(teamId)
                .orElseThrow(() -> new RuntimeException("Team not found"));
        User user = userRepository.findById(userId)
                .orElseThrow(() -> new RuntimeException("User not found"));

        boolean exists = team.getMembers().stream()
                .anyMatch(m -> m.getUser().getId().equals(userId));
        if (exists) {
            return ResponseEntity.badRequest().body(Map.of("error", "User already in team"));
        }

        TeamMember member = TeamMember.builder().team(team).user(user).build();
        team.getMembers().add(member);
        teamRepository.save(team);
        return ResponseEntity.ok(Map.of("message", "Member added"));
    }

    // DELETE remove member
    @DeleteMapping("/{teamId}/members/{userId}")
    public ResponseEntity<?> removeMember(@PathVariable Long teamId, @PathVariable Long userId) {
        Team team = teamRepository.findById(teamId)
                .orElseThrow(() -> new RuntimeException("Team not found"));
        team.getMembers().removeIf(m -> m.getUser().getId().equals(userId));
        teamRepository.save(team);
        return ResponseEntity.ok(Map.of("message", "Member removed"));
    }

    // DELETE team (soft delete)
    @DeleteMapping("/{id}")
    public ResponseEntity<?> deleteTeam(@PathVariable Long id) {
        teamRepository.findById(id).ifPresent(t -> {
            t.setIsActive(false);
            teamRepository.save(t);
        });
        return ResponseEntity.ok(Map.of("message", "Team deactivated"));
    }

    private Map<String, Object> toDto(Team t) {
        List<Map<String, Object>> members = t.getMembers().stream().map(m -> Map.of(
            "userId", (Object) m.getUser().getId(),
            "name", m.getUser().getName(),
            "email", m.getUser().getEmail(),
            "avatarUrl", m.getUser().getAvatarUrl() != null ? m.getUser().getAvatarUrl() : "",
            "productivityScore", m.getUser().getProductivityScore() != null ? m.getUser().getProductivityScore() : 0
        )).collect(Collectors.toList());

        Map<String, Object> dto = new HashMap<>();
        dto.put("id", t.getId());
        dto.put("name", t.getName());
        dto.put("description", t.getDescription() != null ? t.getDescription() : "");
        dto.put("managerId", t.getManager().getId());
        dto.put("managerName", t.getManager().getName());
        dto.put("members", members);
        dto.put("memberCount", members.size());
        dto.put("isActive", t.getIsActive());
        dto.put("createdAt", t.getCreatedAt());
        return dto;
    }
}
