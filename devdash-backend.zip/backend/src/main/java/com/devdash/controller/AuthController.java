package com.devdash.controller;

import com.devdash.dto.AuthDto;
import com.devdash.entity.User;
import com.devdash.repository.UserRepository;
import com.devdash.security.JwtUtils;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.*;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

@RestController
@RequestMapping("/api/auth")
public class AuthController {

    @Autowired AuthenticationManager authenticationManager;
    @Autowired UserRepository userRepository;
    @Autowired PasswordEncoder encoder;
    @Autowired JwtUtils jwtUtils;

    @Value("${app.frontend.url}")
    private String frontendUrl;

    // ── Manager/Admin Login ──────────────────────────────────
    @PostMapping("/login")
    public ResponseEntity<?> login(@Valid @RequestBody AuthDto.LoginRequest req) {
        try {
            Authentication auth = authenticationManager.authenticate(
                    new UsernamePasswordAuthenticationToken(req.getEmail(), req.getPassword()));

            SecurityContextHolder.getContext().setAuthentication(auth);
            String jwt = jwtUtils.generateJwtToken(auth);
            String refresh = jwtUtils.generateRefreshToken(req.getEmail());

            User user = userRepository.findByEmail(req.getEmail())
                    .orElseThrow(() -> new RuntimeException("User not found"));

            return ResponseEntity.ok(AuthDto.AuthResponse.builder()
                    .token(jwt)
                    .refreshToken(refresh)
                    .id(user.getId())
                    .name(user.getName())
                    .email(user.getEmail())
                    .role(user.getRole().name())
                    .avatarUrl(user.getAvatarUrl())
                    .githubUsername(user.getGithubUsername())
                    .build());
        } catch (BadCredentialsException e) {
            return ResponseEntity.status(401).body(Map.of("error", "Invalid credentials"));
        }
    }

    // ── Register ─────────────────────────────────────────────
    @PostMapping("/register")
    public ResponseEntity<?> register(@Valid @RequestBody AuthDto.RegisterRequest req) {
        if (userRepository.existsByEmail(req.getEmail())) {
            return ResponseEntity.badRequest().body(Map.of("error", "Email already in use"));
        }

        User user = User.builder()
                .name(req.getName())
                .email(req.getEmail())
                .password(encoder.encode(req.getPassword()))
                .role(req.getRole())
                .isActive(true)
                .build();

        userRepository.save(user);
        return ResponseEntity.ok(Map.of("message", "User registered successfully"));
    }

    // ── Refresh Token ─────────────────────────────────────────
    @PostMapping("/refresh")
    public ResponseEntity<?> refresh(@RequestBody AuthDto.RefreshTokenRequest req) {
        String token = req.getRefreshToken();
        if (!jwtUtils.validateJwtToken(token)) {
            return ResponseEntity.status(401).body(Map.of("error", "Invalid refresh token"));
        }
        String email = jwtUtils.getEmailFromJwtToken(token);
        String newJwt = jwtUtils.generateTokenFromUsername(email);
        return ResponseEntity.ok(Map.of("token", newJwt));
    }

    // ── OAuth2 Success Redirect ───────────────────────────────
    @GetMapping("/oauth2/success")
    public ResponseEntity<?> oauth2Success() {
        Authentication auth = SecurityContextHolder.getContext().getAuthentication();
        if (auth == null) return ResponseEntity.status(401).body(Map.of("error", "Not authenticated"));

        String email = auth.getName();
        User user = userRepository.findByEmail(email)
                .orElseThrow(() -> new RuntimeException("User not found"));

        String jwt = jwtUtils.generateTokenFromUsername(email);
        return ResponseEntity.ok(AuthDto.AuthResponse.builder()
                .token(jwt)
                .id(user.getId())
                .name(user.getName())
                .email(user.getEmail())
                .role(user.getRole().name())
                .avatarUrl(user.getAvatarUrl())
                .githubUsername(user.getGithubUsername())
                .build());
    }

    // ── Validate Token ────────────────────────────────────────
    @GetMapping("/validate")
    public ResponseEntity<?> validateToken(@RequestHeader("Authorization") String header) {
        String token = header.replace("Bearer ", "");
        boolean valid = jwtUtils.validateJwtToken(token);
        return ResponseEntity.ok(Map.of("valid", valid));
    }
}
