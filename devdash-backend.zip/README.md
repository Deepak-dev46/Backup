# 🚀 DevDash – Developer Productivity Dashboard

A full-stack enterprise SaaS dashboard for tracking developer productivity using GitHub data.

---

## 🏗️ Tech Stack

| Layer       | Technology                          |
|-------------|-------------------------------------|
| Frontend    | React 18, Bootstrap 5, Chart.js     |
| Backend     | Spring Boot 3.2, Spring Security    |
| Auth        | JWT (Managers) + GitHub OAuth2 (Devs) |
| Database    | MySQL 8+                            |
| GitHub      | REST API + Webhooks + Actions       |

---

## 🎨 Design System

| Color         | Hex       | Usage                   |
|---------------|-----------|-------------------------|
| Primary Blue  | `#27235C` | Sidebar, headers         |
| Secondary Purple | `#97247E` | Cards, highlights      |
| Accent Red    | `#E01950` | Alerts, warnings         |
| White         | `#FFFFFF` | Background               |

**Gradient:** `linear-gradient(135deg, #27235C, #97247E, #E01950)`

---

## 🗂️ Project Structure

```
devdash/
├── frontend/                    # React.js application
│   ├── public/
│   └── src/
│       ├── components/
│       │   └── layout/          # Sidebar, Navbar, Layout
│       ├── context/             # AuthContext
│       ├── pages/
│       │   ├── LoginPage.jsx
│       │   ├── developer/       # Dashboard, Repos, Metrics
│       │   └── manager/         # Dashboard, Teams, Insights, Reports
│       └── styles/
│           └── global.css       # Design system tokens & components
│
└── backend/                     # Spring Boot application
    └── src/main/java/com/devdash/
        ├── config/              # Security, CORS, OAuth2, Exception handlers
        ├── controller/          # REST API controllers
        ├── dto/                 # Request/Response DTOs
        ├── entity/              # JPA entities
        ├── repository/          # Spring Data JPA repos
        ├── security/            # JWT utils, filters, UserDetails
        ├── service/             # GitHub API, Metrics (score algorithm)
        └── webhook/             # GitHub Actions webhook receiver
```

---

## ⚡ Quick Start

### Prerequisites
- Node.js 18+, npm 9+
- Java 17+, Maven 3.8+
- MySQL 8+

---

### 1. Database Setup

```sql
CREATE DATABASE devdash_db CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
```

Then run `backend/src/main/resources/schema.sql` or let Spring Boot auto-create via `ddl-auto=update`.

---

### 2. Backend Configuration

Edit `backend/src/main/resources/application.properties`:

```properties
# MySQL
spring.datasource.url=jdbc:mysql://localhost:3306/devdash_db
spring.datasource.username=root
spring.datasource.password=YOUR_PASSWORD

# GitHub OAuth2 (create app at https://github.com/settings/applications/new)
spring.security.oauth2.client.registration.github.client-id=YOUR_CLIENT_ID
spring.security.oauth2.client.registration.github.client-secret=YOUR_CLIENT_SECRET

# GitHub API (create token at https://github.com/settings/tokens)
github.api.token=YOUR_PERSONAL_ACCESS_TOKEN
```

#### Start Backend:
```bash
cd backend
mvn clean install
mvn spring-boot:run
```
API available at: `http://localhost:8080`

---

### 3. Frontend Setup

```bash
cd frontend
npm install
npm start
```
App available at: `http://localhost:3000`

---

## 🔐 Authentication

### Manager Login
- URL: `POST /api/auth/login`
- Demo: `admin@devdash.io` / `password` (bcrypt hash in schema.sql)
- Returns JWT token

### Developer Login (GitHub OAuth2)
1. Click "Continue with GitHub" on login page
2. Authorize the GitHub App
3. Redirected back with JWT token
4. Role set to `DEVELOPER`

---

## 📡 REST API Reference

| Method | Endpoint                          | Role     | Description               |
|--------|-----------------------------------|----------|---------------------------|
| POST   | `/api/auth/login`                 | Public   | Manager JWT login         |
| POST   | `/api/auth/register`              | Public   | Register user             |
| GET    | `/api/users/me`                   | Any      | Current user profile      |
| GET    | `/api/users/developers`           | Manager  | All developers            |
| GET    | `/api/users/leaderboard`          | Manager  | Top performers            |
| GET    | `/api/users/at-risk`              | Manager  | Low-scoring developers    |
| GET    | `/api/repos`                      | Dev      | My repositories           |
| POST   | `/api/repos/sync`                 | Dev      | Sync from GitHub          |
| GET    | `/api/metrics/me`                 | Dev      | My metrics + score        |
| GET    | `/api/metrics/me/weekly`          | Dev      | 7-day commit activity     |
| GET    | `/api/metrics/team`               | Manager  | Full team metrics         |
| GET    | `/api/metrics/leaderboard`        | Manager  | Score leaderboard         |
| GET    | `/api/teams`                      | Manager  | All teams                 |
| POST   | `/api/teams`                      | Manager  | Create team               |
| POST   | `/api/teams/{id}/members/{uid}`   | Manager  | Add member to team        |
| DELETE | `/api/teams/{id}/members/{uid}`   | Manager  | Remove member from team   |
| POST   | `/api/webhook/github`             | Public   | GitHub Actions webhook    |

---

## 🤖 Productivity Score Algorithm

```
Score (0-100) =
  40% × min(commits/60, 1.0)      ← commit frequency
  35% × (merged_prs / total_prs)  ← PR merge rate
  25% × min(additions/5000, 1.0)  ← code volume
```

Scores are recalculated nightly at 2 AM via `@Scheduled`.

---

## 🔔 GitHub Webhook Setup

1. Go to your GitHub repo → **Settings → Webhooks → Add webhook**
2. **Payload URL:** `https://your-domain.com/api/webhook/github`
3. **Content type:** `application/json`
4. **Events:** Select **Workflow runs**, **Pushes**, **Pull requests**

---

## 🌙 Features

- ✅ Split-screen login page (GitHub OAuth + Manager JWT)
- ✅ Role-based routing (Developer / Manager)
- ✅ Fixed sidebar with dark blue (#27235C) branding
- ✅ KPI cards with trend indicators
- ✅ Line/Bar/Pie/Doughnut charts via Chart.js
- ✅ GitHub Actions webhook receiver
- ✅ Contribution heatmap
- ✅ Developer leaderboard with score rings
- ✅ Low-performer alerts (red #E01950)
- ✅ Team management with modal forms
- ✅ PDF/CSV export buttons
- ✅ Dark mode toggle
- ✅ Notification bell with dropdown
- ✅ Responsive Bootstrap 5 grid
- ✅ Productivity score algorithm
- ✅ Nightly scheduled score recalculation

---

## 📦 Build for Production

```bash
# Frontend
cd frontend && npm run build

# Backend
cd backend && mvn clean package -DskipTests
java -jar target/devdash-backend-1.0.0.jar
```
